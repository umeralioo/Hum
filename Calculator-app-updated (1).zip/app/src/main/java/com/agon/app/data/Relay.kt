package com.agon.app.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class RelayEvent(val id: String, val time: Long, val body: String)

/**
 * Zero-knowledge relay over ntfy pub/sub — now MULTI-SERVER.
 *
 * Every publish is mirrored to all servers (primary synchronously, the
 * rest in the background), and reads fail over between servers. If one
 * host is slow or unreachable from a member's network, the box still
 * works through the other — this is what makes joining fast and reliable.
 *
 * The topic name is derived from an unguessable random box id, and every
 * payload is an AES-GCM-256 ciphertext envelope ("iv.ct"). The relays
 * never see plaintext, member names, or key material.
 */
object Relay {

    /** Mirrored relay servers; order = preference. More servers = more
     *  independent rate-limit budgets = higher sustained throughput. */
    val SERVERS = listOf(
        "https://ntfy.sh",
        "https://ntfy.envs.net",
        "https://ntfy.adminforge.de",
    )

    /**
     * Short-lived connection pools: half-open TCP connections (network
     * switches, NAT timeouts, radio sleep) previously got reused and hung
     * until long timeouts expired — the cause of multi-minute send stalls.
     * Aggressive eviction + hard call timeouts bound every request.
     */
    // 5-minute keep-alive + active warming (below) = connections stay hot
    // 24/7, so every send skips TCP+TLS handshakes and goes out instantly.
    private fun pool() = okhttp3.ConnectionPool(6, 300, TimeUnit.SECONDS)

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS)
        .connectionPool(pool())
        .retryOnConnectionFailure(true)
        .build()

    /** Snappy client for join validation: fail fast, fail over faster. */
    private val joinClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .connectionPool(pool())
        .retryOnConnectionFailure(true)
        .build()

    /**
     * Long-lived streaming client; ntfy keepalives arrive every ~45s.
     * Read timeout 58s = a silently-dead stream (network switch, NAT drop)
     * is detected and replaced within a minute instead of hanging.
     */
    private val streamClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(58, TimeUnit.SECONDS)
        .connectionPool(pool())
        .retryOnConnectionFailure(true)
        .build()

    /** Background mirroring so extra servers never add send latency. */
    private val mirrorPool = Executors.newFixedThreadPool(2)

    /** Dedicated pool for parallel fast-path publishes (latency-critical). */
    private val fastPool = Executors.newCachedThreadPool()

    /** Low-latency client for fast-path sends: hard-bounded at 10s total. */
    private val fastClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .connectionPool(pool())
        .retryOnConnectionFailure(true)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    private fun parseEvent(line: String): RelayEvent? = runCatching {
        val obj = json.parseToJsonElement(line).jsonObject
        if (obj["event"]?.jsonPrimitive?.content == "message") {
            RelayEvent(
                id = obj["id"]!!.jsonPrimitive.content,
                time = obj["time"]!!.jsonPrimitive.long,
                body = obj["message"]!!.jsonPrimitive.content,
            )
        } else null
    }.getOrNull()

    /**
     * Rate-limit awareness: relay servers allow a burst of requests per
     * client and then return 429. A rate-limited server goes into a short
     * cooldown so traffic instantly fails over to the mirror instead of
     * hammering the throttled host — this is what previously froze the box
     * ("everything offline") after ~15-20 rapid messages.
     */
    private val cooldownUntil = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun usable(server: String): Boolean =
        (cooldownUntil[server] ?: 0L) < System.currentTimeMillis()

    // ------------------------------------------------------ token budget
    //
    // PERMANENT rate-limit fix: ntfy servers allow ~60 requests burst per
    // visitor, refilling ~1 request / 5s. We mirror that budget CLIENT-SIDE
    // (with headroom) so the app physically cannot exhaust a server: when
    // one bucket runs low, traffic rotates to the other server; ephemeral
    // events (typing/heartbeats) are dropped before they can starve real
    // messages. Result: the channel stays live 24/7 like WhatsApp.

    private const val BUCKET_CAP = 50.0          // headroom under the 60 burst
    private const val REFILL_PER_MS = 1.0 / 5200.0 // ≈ 1 token / 5.2s

    /** Combined tokens currently available across all servers. */
    fun totalBudget(): Double = SERVERS.sumOf { tokensAvailable(it) }

    private val bucketLock = Any()
    private val tokens = HashMap<String, Double>()
    private val lastRefill = HashMap<String, Long>()

    private fun tokensAvailable(server: String): Double = synchronized(bucketLock) {
        val now = System.currentTimeMillis()
        val cur = tokens[server] ?: BUCKET_CAP
        val last = lastRefill[server] ?: now
        val refilled = minOf(BUCKET_CAP, cur + (now - last) * REFILL_PER_MS)
        tokens[server] = refilled
        lastRefill[server] = now
        refilled
    }

    private fun tryAcquire(server: String): Boolean = synchronized(bucketLock) {
        val avail = tokensAvailable(server)
        if (avail < 1.0) return false
        tokens[server] = avail - 1.0
        true
    }

    /** Round-robin pointer so consecutive events alternate servers. */
    private val rr = java.util.concurrent.atomic.AtomicInteger(0)

    /**
     * Connection warmer: a tiny GET to the server's health endpoint. It is
     * NOT a publish — it costs no message tokens — but it (a) keeps the
     * TCP+TLS connection alive in the pool, and (b) refreshes carrier NAT
     * mappings, so the NEXT real message reuses a hot socket and ships in
     * one RTT. This is the WhatsApp-style always-warm channel.
     */
    fun warm(server: String): Boolean = try {
        val request = Request.Builder().url("$server/v1/health").build()
        fastClient.newCall(request).execute().use { it.isSuccessful }
    } catch (_: Exception) {
        false
    }

    fun warmAll() {
        for (server in SERVERS) fastPool.execute { warm(server) }
    }

    private fun publishTo(
        server: String,
        topic: String,
        body: String,
        c: OkHttpClient = client,
    ): Boolean = try {
        val request = Request.Builder()
            .url("$server/$topic")
            .post(body.toRequestBody("text/plain; charset=utf-8".toMediaType()))
            .build()
        c.newCall(request).execute().use { resp ->
            if (resp.code == 429) {
                val retry = resp.header("Retry-After")?.toLongOrNull()?.coerceIn(5, 60) ?: 20L
                cooldownUntil[server] = System.currentTimeMillis() + retry * 1000
            }
            resp.isSuccessful
        }
    } catch (_: Exception) {
        false
    }

    /**
     * Latency-critical publish: fires at BOTH servers simultaneously and
     * returns as soon as the FIRST one accepts (the other continues in the
     * background as the mirror). Wire time ≈ fastest server's RTT, which
     * is what makes ~300ms end-to-end delivery possible.
     */
    /**
     * Latency-critical publish, budget-aware. ONE request per event
     * (round-robin across servers — half the old cost, double the total
     * capacity), with instant failover to the other server on failure.
     * Everyone streams from all servers, so single-server delivery is
     * always sufficient.
     */
    fun publishFast(topic: String, body: String): Boolean {
        val start = rr.getAndIncrement()
        val order = List(SERVERS.size) { SERVERS[(start + it) % SERVERS.size] }
        // Pass 1: healthy servers with budget.
        for (server in order) {
            if (usable(server) && tryAcquire(server)) {
                if (publishTo(server, topic, body, fastClient)) return true
            }
        }
        // Pass 2: any server with budget (even if recently throttled).
        for (server in order) {
            if (tryAcquire(server) && publishTo(server, topic, body, fastClient)) return true
        }
        return false
    }

    /**
     * Low-priority publish for typing/heartbeat/presence pings: sends only
     * when budget is PLENTIFUL and silently drops otherwise — ephemeral
     * chatter can never starve real messages of tokens.
     */
    fun publishEphemeralBudget(topic: String, body: String): Boolean {
        val server = SERVERS.firstOrNull { usable(it) && tokensAvailable(it) > 12.0 }
            ?: return false
        if (!tryAcquire(server)) return false
        return publishTo(server, topic, body, fastClient)
    }

    /**
     * Publishes to the first reachable server and mirrors to the rest in
     * the background. Success = at least one server accepted the event.
     */
    fun publish(topic: String, body: String): Boolean {
        val ordered = SERVERS.sortedByDescending { usable(it) }
        for (server in ordered) {
            if (tryAcquire(server) && publishTo(server, topic, body)) {
                // Mirror only when the other server's budget is plentiful —
                // mirroring is a luxury, message capacity is not.
                ordered.forEach { other ->
                    if (other != server && usable(other) && tokensAvailable(other) > 20.0 && tryAcquire(other)) {
                        mirrorPool.execute { publishTo(other, topic, body) }
                    }
                }
                return true
            }
        }
        return false
    }

    /** Publish with automatic retries + backoff across all servers. */
    fun publishWithRetry(topic: String, body: String, attempts: Int = 3): Boolean {
        for (i in 0 until attempts) {
            if (publish(topic, body)) return true
            if (i < attempts - 1) {
                try {
                    Thread.sleep(600L * (i + 1))
                } catch (_: InterruptedException) {
                    return false
                }
            }
        }
        return false
    }

    /** Polls one server. Returns null on network failure. */
    fun pollFrom(
        server: String,
        topic: String,
        since: String,
        c: OkHttpClient = client,
    ): List<RelayEvent>? = try {
        val request = Request.Builder()
            .url("$server/$topic/json?poll=1&since=$since")
            .build()
        c.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) {
                null
            } else {
                resp.body?.string().orEmpty()
                    .lineSequence()
                    .filter { it.isNotBlank() }
                    .mapNotNull { parseEvent(it) }
                    .toList()
            }
        }
    } catch (_: Exception) {
        null
    }

    /** Snappy single-server poll used for parallel join racing. */
    fun pollFast(server: String, topic: String, since: String = "all"): List<RelayEvent>? =
        pollFrom(server, topic, since, joinClient)

    /**
     * Join validation fetch: queries ALL servers in parallel and MERGES
     * their histories (deduped by envelope, ordered by time). Mirroring is
     * best-effort, so a single server may be missing the owner's latest
     * invite state — validating against the merged union prevents false
     * "expired token" verdicts. Returns per-server cursors + merged events.
     */
    fun pollMerged(
        topic: String,
        since: String = "all",
    ): Pair<Map<String, String>, List<RelayEvent>>? {
        val results = java.util.concurrent.ConcurrentHashMap<String, List<RelayEvent>>()
        val latch = java.util.concurrent.CountDownLatch(SERVERS.size)
        for (server in SERVERS) {
            fastPool.execute {
                try {
                    pollFrom(server, topic, since, joinClient)?.let { results[server] = it }
                } finally {
                    latch.countDown()
                }
            }
        }
        try {
            latch.await(16, TimeUnit.SECONDS)
        } catch (_: InterruptedException) {
            return null
        }
        if (results.isEmpty()) return null
        val cursors = results.mapNotNull { (server, events) ->
            events.lastOrNull()?.let { server to it.id }
        }.toMap()
        val seen = HashSet<String>()
        val merged = results.values.flatten()
            .sortedWith(compareBy({ it.time }, { it.id }))
            .filter { seen.add(it.body) }
        return cursors to merged
    }

    /**
     * Join validation fetch: interleaves servers with short timeouts so a
     * slow/unreachable host fails over in seconds instead of stalling the
     * whole redemption. Returns (server, events) from the first success.
     */
    fun pollAny(
        topic: String,
        since: String = "all",
        rounds: Int = 3,
    ): Pair<String, List<RelayEvent>>? {
        for (round in 0 until rounds) {
            for (server in SERVERS) {
                pollFrom(server, topic, since, joinClient)?.let { return server to it }
            }
            if (round < rounds - 1) {
                try {
                    Thread.sleep(600L * (round + 1))
                } catch (_: InterruptedException) {
                    return null
                }
            }
        }
        return null
    }

    /**
     * Live streaming subscription to one server: blocks reading the topic
     * and invokes [onEvent] the instant an event lands. Returns when the
     * connection drops or [isActive] turns false. Returns true if the
     * connection was established successfully.
     */
    fun stream(
        server: String,
        topic: String,
        since: String,
        isActive: () -> Boolean,
        onOpen: () -> Unit,
        onEvent: (RelayEvent) -> Unit,
    ): Boolean = try {
        val request = Request.Builder()
            .url("$server/$topic/json?since=$since")
            .build()
        streamClient.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) {
                false
            } else {
                onOpen()
                val source = resp.body?.source()
                if (source != null) {
                    while (isActive()) {
                        val line = source.readUtf8Line() ?: break
                        if (line.isBlank()) continue
                        parseEvent(line)?.let(onEvent)
                    }
                }
                true
            }
        }
    } catch (_: Exception) {
        false
    }
}
