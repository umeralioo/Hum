package com.agon.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.ui.theme.Coral
import com.agon.app.ui.theme.OnlineGreen
import com.agon.app.ui.theme.SoftGray
import com.agon.app.ui.theme.Zinc
import com.agon.app.ui.theme.ZincHigh
import com.agon.app.ui.theme.ZincBorder

@Composable
fun PresenceDot(online: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val alpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (online) 0.55f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulseAlpha",
    )
    Box(
        modifier = modifier
            .size(9.dp)
            .alpha(if (online) alpha else 1f)
            .clip(CircleShape)
            .background(if (online) OnlineGreen else SoftGray.copy(alpha = 0.5f))
    )
}

@Composable
fun MemberAvatar(
    name: String,
    isOwner: Boolean,
    size: Int = 40,
    glow: Color? = null,
) {
    // Neon ring: owner stays crimson, others take the supplied glow color
    // (e.g. presence green) when one is given, else the plain surface border.
    val ring = when {
        isOwner -> Color(0xFFBA2131)
        glow != null -> glow
        else -> ZincBorder
    }
    val base = Modifier
        .size(size.dp)
        .clip(CircleShape)
        .background(Color(0xFF7A1420))
        .border(1.dp, ring, CircleShape)
    val styled = if (glow != null || isOwner) {
        base.shadow(8.dp, CircleShape, ambientColor = ring, spotColor = ring)
    } else base
    Box(
        modifier = styled,
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name.take(1).uppercase(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size * 0.42).sp,
        )
    }
}

@Composable
fun CoralBadge(text: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = Coral.copy(alpha = 0.14f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Coral.copy(alpha = 0.45f)),
    ) {
        Text(
            text = text,
            color = Coral,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.2.sp,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
        )
    }
}

@Composable
fun TypingDots(color: Color = SoftGray) {
    val transition = rememberInfiniteTransition(label = "typing")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "typingPhase",
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val active = phase.toInt() % 3 == i
            Box(
                modifier = Modifier
                    .padding(horizontal = 2.dp)
                    .size(if (active) 6.dp else 4.dp)
                    .clip(CircleShape)
                    .background(if (active) color else color.copy(alpha = 0.4f))
            )
        }
        Box(Modifier.width(2.dp))
    }
}
