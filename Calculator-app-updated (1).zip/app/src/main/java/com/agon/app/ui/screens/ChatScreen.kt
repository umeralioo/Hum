package com.agon.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material.icons.outlined.ManageAccounts
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.ui.components.MemberAvatar
import com.agon.app.ui.components.TypingDots
import com.agon.app.ui.theme.AvatarRed
import com.agon.app.ui.theme.ChatBg
import com.agon.app.ui.theme.DimGray
import com.agon.app.ui.theme.HeaderBg
import com.agon.app.ui.theme.InkLight
import com.agon.app.ui.theme.MutedGray
import com.agon.app.ui.theme.ReadBlue
import com.agon.app.ui.theme.RecvBubble
import com.agon.app.ui.theme.RecvBubbleDeep
import com.agon.app.ui.theme.RecvBubbleTop
import com.agon.app.ui.theme.RecvMeta
import com.agon.app.ui.theme.SentBubble
import com.agon.app.ui.theme.SentText
import com.agon.app.ui.theme.SendBtnRed
import com.agon.app.ui.theme.SentBubbleTop
import com.agon.app.ui.theme.SentMeta
import com.agon.app.ui.theme.SurfaceBorder
import com.agon.app.ui.theme.SurfaceDark
import com.agon.app.ui.theme.ZincHigh
import com.agon.app.viewmodel.ChatUiState
import com.agon.app.viewmodel.ChatViewModel
import com.agon.app.viewmodel.MessageStatus
import com.agon.app.viewmodel.MessageUi
import com.agon.app.viewmodel.containsLink
import com.agon.app.viewmodel.sanitizePlainText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    vm: ChatViewModel,
    state: ChatUiState,
    onOpenManage: () -> Unit,
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val totalItems = state.messages.size + if (state.typingName != null) 1 else 0

    // Near bottom when last visible is within ~2 items of the end.
    val nearBottom by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            if (info.totalItemsCount == 0) true
            else {
                val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: 0
                lastVisible >= info.totalItemsCount - 2
            }
        }
    }

    // Auto-follow only when already near bottom. Instant snap (no animation)
    // so a fast send/recv burst at the bottom feels like Telegram — the
    // bubble is already there, never a chasing animation. The FAB below keeps
    // its slow animated scroll for deliberate jumps.
    LaunchedEffect(state.messages.size, state.typingName) {
        if (totalItems <= 0) return@LaunchedEffect
        if (nearBottom) {
            listState.scrollToItem(totalItems - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ChatBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        ChatHeader(vm, state, onOpenManage)

        Box(modifier = Modifier.weight(1f)) {
            // Subtle dark messaging doodle pattern (low contrast)
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Ultra-low-contrast watermark pattern (screenshot style)
                val step = 48.dp.toPx()
                val ink = Color(0xFF16161A)
                var y = 24f
                var row = 0
                while (y < size.height) {
                    var x = if (row % 2 == 0) 16f else 40f
                    while (x < size.width) {
                        drawCircle(color = ink, radius = 2.2f, center = Offset(x, y))
                        drawCircle(color = ink.copy(alpha = 0.5f), radius = 6f, center = Offset(x + 14f, y + 10f))
                        drawRoundRect(
                            color = ink.copy(alpha = 0.35f),
                            topLeft = Offset(x + 22f, y - 4f),
                            size = androidx.compose.ui.geometry.Size(10f, 7f),
                            cornerRadius = CornerRadius(3f, 3f),
                        )
                        x += step
                    }
                    y += step
                    row++
                }
            }
            if (state.messages.isEmpty()) {
                EmptyChannel()
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    userScrollEnabled = true,
                ) {
                    items(state.messages, key = { it.id }) { msg ->
                        if (msg.system) {
                            SystemBubble(msg)
                        } else {
                            MessageBubble(msg, onDelete = { vm.deleteMessage(msg.id) })
                        }
                    }
                    if (state.typingName != null) {
                        item(key = "typing") {
                            TypingBubble(state.typingName)
                        }
                    }
                }
            }

            // Scroll-to-bottom FAB — use standalone AnimatedVisibility (not ColumnScope)
            // so BoxScope.align works without a receiver clash.
            val showScrollBtn = !nearBottom && state.messages.isNotEmpty()
            androidx.compose.animation.AnimatedVisibility(
                visible = showScrollBtn,
                enter = fadeIn(tween(160)) + scaleIn(tween(160), initialScale = 0.85f),
                exit = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.85f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 14.dp, bottom = 12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .shadow(6.dp, CircleShape)
                        .clip(CircleShape)
                        .background(SurfaceDark)
                        .clickable {
                            scope.launch {
                                if (totalItems > 0) {
                                    listState.animateScrollToItem(totalItems - 1)
                                }
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Default.KeyboardArrowDown,
                        contentDescription = "Scroll to bottom",
                        tint = InkLight,
                        modifier = Modifier.size(26.dp),
                    )
                }
            }
        }

        Composer(vm, state)
    }
}

@Composable
private fun ChatHeader(vm: ChatViewModel, state: ChatUiState, onOpenManage: () -> Unit) {
    val peer = state.members.firstOrNull { !it.isSelf }
    val online = peer?.online == true
    val neon = if (online) Color(0xFF25D366) else Color(0xFFE03040)

    // Slim header — no large board; small neon-ring avatar
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0A0A0C))
            .padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Box(contentAlignment = Alignment.Center) {
            // Outer neon glow ring
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .shadow(10.dp, CircleShape, ambientColor = neon, spotColor = neon)
                    .border(1.8.dp, neon.copy(alpha = 0.95f), CircleShape)
                    .padding(2.dp)
                    .border(1.dp, neon.copy(alpha = 0.35f), CircleShape)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(listOf(Color(0xFF8A1A28), Color(0xFF3A0C12))),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                val letter = (peer?.name ?: state.selfName).ifBlank { "B" }.take(1).uppercase()
                Text(letter, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                peer?.name ?: state.selfName.ifBlank { "Chat" },
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = Color.White,
                maxLines = 1,
            )
            val statusLine = when {
                !state.connected -> "offline · queued"
                peer == null -> "only you"
                online -> "online"
                else -> formatLastSeen(peer.lastSeenAt).removePrefix("last seen ").let { "last seen $it" }
            }
            Text(
                statusLine,
                color = if (online) Color(0xFF25D366) else MutedGray,
                fontSize = 11.sp,
                maxLines = 1,
            )
        }
        IconButton(onClick = { vm.toggleAudio() }, modifier = Modifier.size(36.dp)) {
            Icon(
                if (state.audioEnabled) Icons.AutoMirrored.Filled.VolumeUp
                else Icons.AutoMirrored.Filled.VolumeOff,
                contentDescription = "Toggle audio",
                tint = if (state.audioEnabled) Color.White else DimGray,
                modifier = Modifier.size(18.dp),
            )
        }
        IconButton(onClick = onOpenManage, modifier = Modifier.size(36.dp)) {
            Icon(
                Icons.Outlined.ManageAccounts,
                contentDescription = "Manage",
                tint = MutedGray,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

@Composable
private fun EmptyChannel() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(ZincHigh),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Default.Lock, null, tint = RecvBubbleTop.copy(alpha = 0.85f), modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("No messages yet", color = InkLight, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Messages disappear after 3 hours.\nOnly people in this box can read them.",
            color = MutedGray,
            fontSize = 13.sp,
            lineHeight = 18.sp,
        )
    }
}

private val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
private val fullFmt = SimpleDateFormat("EEE d MMM · h:mm:ss a", Locale.getDefault())
private val lastSeenTimeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
private val lastSeenDateFmt = SimpleDateFormat("d MMM · h:mm a", Locale.getDefault())

fun formatLastSeen(at: Long): String {
    if (at <= 0L) return "last seen a while ago"
    val now = System.currentTimeMillis()
    val diff = now - at
    if (diff < 45_000) return "last seen just now"
    if (diff < 3_600_000) return "last seen ${diff / 60_000}m ago"

    val calAt = java.util.Calendar.getInstance().apply { timeInMillis = at }
    val calNow = java.util.Calendar.getInstance().apply { timeInMillis = now }
    val sameDay = calAt.get(java.util.Calendar.YEAR) == calNow.get(java.util.Calendar.YEAR) &&
        calAt.get(java.util.Calendar.DAY_OF_YEAR) == calNow.get(java.util.Calendar.DAY_OF_YEAR)
    calNow.add(java.util.Calendar.DAY_OF_YEAR, -1)
    val yesterday = calAt.get(java.util.Calendar.YEAR) == calNow.get(java.util.Calendar.YEAR) &&
        calAt.get(java.util.Calendar.DAY_OF_YEAR) == calNow.get(java.util.Calendar.DAY_OF_YEAR)
    val time = lastSeenTimeFmt.format(Date(at))
    return when {
        sameDay -> "last seen today at $time"
        yesterday -> "last seen yesterday at $time"
        else -> "last seen ${lastSeenDateFmt.format(Date(at))}"
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    msg: MessageUi,
    modifier: Modifier = Modifier,
    onDelete: () -> Unit = {},
) {
    var expanded by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val align = if (msg.isMine) Alignment.CenterEnd else Alignment.CenterStart

    // Compact neon bubbles — small body, continuous edge glow
    val bubbleBrush = when {
        msg.status == MessageStatus.FAILED -> Brush.verticalGradient(listOf(Color(0xFF3A2222), Color(0xFF2A1515)))
        msg.isMine -> Brush.verticalGradient(
            listOf(Color(0xFF2E2E36), Color(0xFF222228), Color(0xFF18181C)),
        )
        else -> Brush.verticalGradient(
            listOf(Color(0xFFB01A28), Color(0xFF8A121C), Color(0xFF5C0A12)),
        )
    }
    // Continuous neon edge color
    val neon = when {
        msg.status == MessageStatus.FAILED -> Color(0xFFFF6B6B)
        msg.isMine -> Color(0xFF8B8B9A)
        else -> Color(0xFFFF3D55)
    }
    val metaColor = when {
        msg.status == MessageStatus.FAILED -> Color(0xFFFF8A80)
        msg.isMine -> Color(0xFF9A9AA3)
        else -> Color(0xFFC8989E)
    }
    val shape = remember(msg.isMine) { ChatBubbleShape(isMine = msg.isMine) }

    Box(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp)
            .then(modifier),
        contentAlignment = align,
    ) {
        Column(horizontalAlignment = if (msg.isMine) Alignment.End else Alignment.Start) {
            Box {
                Column(
                    modifier = Modifier
                        .widthIn(min = 48.dp, max = 240.dp)
                        // Soft outer neon glow
                        .shadow(
                            elevation = 12.dp,
                            shape = shape,
                            ambientColor = neon.copy(alpha = 0.85f),
                            spotColor = neon.copy(alpha = 0.7f),
                        )
                        .shadow(
                            elevation = 4.dp,
                            shape = shape,
                            ambientColor = Color.Black.copy(alpha = 0.6f),
                            spotColor = Color.Black.copy(alpha = 0.5f),
                        )
                        .clip(shape)
                        .background(bubbleBrush)
                        // Continuous neon rim
                        .border(width = 1.5.dp, color = neon.copy(alpha = 0.9f), shape = shape)
                        .border(width = 0.7.dp, color = neon.copy(alpha = 0.35f), shape = shape)
                        .combinedClickable(
                            onClick = { expanded = !expanded },
                            onLongClick = { if (msg.isMine) menu = true },
                        )
                        .padding(
                            start = if (msg.isMine) 10.dp else 14.dp,
                            end = if (msg.isMine) 14.dp else 10.dp,
                            top = 6.dp,
                            bottom = 5.dp,
                        ),
                ) {
                    Text(
                        msg.text,
                        color = Color.White,
                        fontSize = 12.5.sp,
                        lineHeight = 16.sp,
                    )
                    Spacer(Modifier.height(1.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.align(Alignment.End),
                    ) {
                        if (msg.status == MessageStatus.FAILED) {
                            Text("not sent", color = Color(0xFFFF8A80), fontSize = 8.sp)
                            Spacer(Modifier.width(3.dp))
                        }
                        Text(
                            timeFmt.format(Date(msg.timestamp)),
                            color = metaColor,
                            fontSize = 8.sp,
                        )
                        if (msg.isMine && msg.status != MessageStatus.FAILED) {
                            Spacer(Modifier.width(2.dp))
                            when (msg.status) {
                                MessageStatus.SENT -> Icon(
                                    Icons.Default.Done, null,
                                    tint = metaColor, modifier = Modifier.size(11.dp),
                                )
                                MessageStatus.DELIVERED -> Icon(
                                    Icons.Default.DoneAll, null,
                                    tint = metaColor, modifier = Modifier.size(11.dp),
                                )
                                MessageStatus.READ -> Icon(
                                    Icons.Default.DoneAll, null,
                                    tint = ReadBlue, modifier = Modifier.size(11.dp),
                                )
                                else -> Unit
                            }
                        }
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Delete for everyone", color = Color(0xFFEF4444)) },
                        onClick = {
                            menu = false
                            onDelete()
                        },
                    )
                }
            }
            AnimatedVisibility(visible = expanded, enter = fadeIn(), exit = fadeOut()) {
                Column(Modifier.padding(top = 3.dp, start = 4.dp, end = 4.dp)) {
                    Text(
                        fullFmt.format(Date(msg.timestamp)) +
                            if (msg.isMine) "  ·  ${msg.status.name.lowercase()}" else "",
                        color = MutedGray.copy(alpha = 0.85f),
                        fontSize = 10.sp,
                    )
                    if (msg.isMine && msg.seenBy.isNotBlank()) {
                        Text(
                            "seen by ${msg.seenBy}",
                            color = ReadBlue.copy(alpha = 0.9f),
                            fontSize = 10.sp,
                        )
                    }
                }
            }
        }
    }
}

/**
 * Longer tail + rounder body + clean silhouette for premium chat bubbles.
 */
private class ChatBubbleShape(
    private val isMine: Boolean,
) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density,
    ): Outline {
        // Rounder corners + longer speech tail
        val r = with(density) { 16.dp.toPx() }
        val tail = with(density) { 12.dp.toPx() }
        val w = size.width
        val h = size.height
        val path = Path()

        if (isMine) {
            // Sent — long tail bottom-right
            val br = (w - tail).coerceAtLeast(r * 2f)
            path.moveTo(r, 0f)
            path.lineTo(br - r, 0f)
            path.quadraticBezierTo(br, 0f, br, r)
            path.lineTo(br, (h - tail * 0.7f).coerceAtLeast(r))
            // elongated tip
            path.lineTo(w, h)
            path.lineTo(br - tail * 0.45f, h)
            path.lineTo(r, h)
            path.quadraticBezierTo(0f, h, 0f, h - r)
            path.lineTo(0f, r)
            path.quadraticBezierTo(0f, 0f, r, 0f)
            path.close()
        } else {
            // Received — long tail bottom-left
            val bl = tail
            path.moveTo(bl + r, 0f)
            path.lineTo(w - r, 0f)
            path.quadraticBezierTo(w, 0f, w, r)
            path.lineTo(w, h - r)
            path.quadraticBezierTo(w, h, w - r, h)
            path.lineTo(bl + tail * 0.45f, h)
            // elongated tip
            path.lineTo(0f, h)
            path.lineTo(bl, (h - tail * 0.7f).coerceAtLeast(r))
            path.lineTo(bl, r)
            path.quadraticBezierTo(bl, 0f, bl + r, 0f)
            path.close()
        }
        return Outline.Generic(path)
    }
}

@Composable
private fun SystemBubble(msg: MessageUi, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().then(modifier), contentAlignment = Alignment.Center) {
        Surface(
            shape = RoundedCornerShape(50),
            color = ZincHigh,
            border = BorderStroke(1.dp, SurfaceBorder),
        ) {
            Text(
                msg.text,
                color = MutedGray,
                fontSize = 10.5.sp,
                fontStyle = FontStyle.Italic,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            )
        }
    }
}

@Composable
private fun TypingBubble(name: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 2.dp),
    ) {
        MemberAvatar(name = name, isOwner = false, size = 26)
        Spacer(Modifier.width(8.dp))
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = SurfaceDark,
            border = BorderStroke(1.dp, SurfaceBorder),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                Text("typing", color = MutedGray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(8.dp))
                TypingDots(color = RecvBubbleTop)
            }
        }
    }
}

@Composable
private fun Composer(vm: ChatViewModel, state: ChatUiState) {
    var input by remember { mutableStateOf("") }
    val hasLink = containsLink(input)
    val canSend = input.isNotBlank() && !hasLink

    Column(Modifier.background(HeaderBg)) {
        AnimatedVisibility(
            visible = hasLink,
            enter = slideInVertically { it } + fadeIn(),
            exit = fadeOut(),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF3A1518))
                    .padding(horizontal = 16.dp, vertical = 7.dp),
            ) {
                Icon(
                    Icons.Outlined.LinkOff, null,
                    tint = Color(0xFFFF8A80),
                    modifier = Modifier.size(15.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "Links and media are strictly disabled.",
                    color = Color(0xFFFF8A80),
                    fontSize = 11.5.sp,
                )
            }
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
        ) {
            TextField(
                value = input,
                onValueChange = {
                    input = sanitizePlainText(it).take(1000)
                    if (input.isNotBlank()) vm.onTyping()
                },
                placeholder = { Text("Type a message...", color = DimGray, fontSize = 13.sp) },
                shape = RoundedCornerShape(22.dp),
                maxLines = 4,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF141418),
                    unfocusedContainerColor = Color(0xFF141418),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Color(0xFFFF3D55),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                ),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, Color(0xFF2A2A32), RoundedCornerShape(22.dp)),
            )
            Spacer(Modifier.width(8.dp))
            // Neon send — glows when text is ready, scales down on press
            val sendNeon = Color(0xFFFF3D55)
            val sendInteraction = remember { MutableInteractionSource() }
            val sendPressed by sendInteraction.collectIsPressedAsState()
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .scale(if (sendPressed) 0.9f else 1f)
                    .then(
                        if (canSend) Modifier.shadow(10.dp, CircleShape, ambientColor = sendNeon, spotColor = sendNeon)
                        else Modifier
                    )
                    .clip(CircleShape)
                    .background(
                        if (canSend) Brush.radialGradient(listOf(Color(0xFFFF4A60), Color(0xFFB01020)))
                        else Brush.radialGradient(listOf(Color(0xFF2A2A32), Color(0xFF1A1A1E))),
                    )
                    .border(
                        width = if (canSend) 1.5.dp else 1.dp,
                        color = if (canSend) sendNeon else Color(0xFF33333A),
                        shape = CircleShape,
                    )
                    .clickable(
                        interactionSource = sendInteraction,
                        indication = null,
                        enabled = canSend,
                    ) {
                        val text = input
                        input = ""
                        if (!vm.sendMessage(text) && text.isNotBlank()) {
                            input = text
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = if (canSend) Color.White else DimGray,
                    modifier = Modifier.size(17.dp),
                )
            }
        }
    }
}
