package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.agon.app.ui.screens.ChatScreen
import com.agon.app.ui.screens.GateScreen
import com.agon.app.ui.screens.ManageScreen
import com.agon.app.ui.theme.AgonAppTheme
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.Coral
import com.agon.app.ui.theme.Cream
import com.agon.app.ui.theme.Cream
import com.agon.app.viewmodel.ChatViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AgonAppTheme {
                BlackBoxApp()
            }
        }
    }
}

private enum class BoxRoute { GATE, CHAT, MANAGE }

@Composable
fun BlackBoxApp() {
    val vm: ChatViewModel = viewModel()
    val state by vm.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var route by remember { mutableStateOf(BoxRoute.GATE) }

    // Accurate presence: announce enter/leave the moment the user opens or
    // leaves the chat, so peers see online/offline (and last seen) live.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> vm.onAppForeground()
                Lifecycle.Event.ON_STOP -> vm.onAppBackground()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Subtle alerts (invite lifecycle, channel guard, revocations).
    LaunchedEffect(state.notice) {
        state.notice?.let {
            snackbar.showSnackbar(it)
            vm.clearNotice()
        }
    }

    // Gate <-> Chat routing follows vault initialization.
    LaunchedEffect(state.initialized) {
        route = if (state.initialized) {
            if (route == BoxRoute.MANAGE) BoxRoute.MANAGE else BoxRoute.CHAT
        } else {
            BoxRoute.GATE
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(com.agon.app.ui.theme.ChatBg),
    ) {
        if (state.loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Coral)
            }
        } else {
            AnimatedContent(
                targetState = route,
                transitionSpec = {
                    // Fast, light transitions similar to WhatsApp navigation.
                    val enter = fadeIn(animationSpec = androidx.compose.animation.core.tween(120)) +
                        slideInHorizontally(animationSpec = androidx.compose.animation.core.tween(130)) {
                            if (targetState == BoxRoute.MANAGE) it / 6 else -it / 6
                        }
                    val exit = fadeOut(animationSpec = androidx.compose.animation.core.tween(90)) +
                        slideOutHorizontally(animationSpec = androidx.compose.animation.core.tween(120)) {
                            if (targetState == BoxRoute.MANAGE) -it / 8 else it / 8
                        }
                    enter togetherWith exit
                },
                label = "route",
            ) { current ->
                when (current) {
                    BoxRoute.GATE -> GateScreen(vm)
                    BoxRoute.CHAT -> ChatScreen(
                        vm = vm,
                        state = state,
                        onOpenManage = { route = BoxRoute.MANAGE },
                    )
                    BoxRoute.MANAGE -> ManageScreen(
                        vm = vm,
                        state = state,
                        onBack = { route = if (state.initialized) BoxRoute.CHAT else BoxRoute.GATE },
                    )
                }
            }
        }
        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}
