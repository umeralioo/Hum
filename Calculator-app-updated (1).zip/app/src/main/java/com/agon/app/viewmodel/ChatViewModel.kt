package com.agon.app.viewmodel

import android.app.Application
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.AudioSynth
import com.agon.app.data.CryptoEngine
import com.agon.app.data.InvitePayload
import com.agon.app.data.Relay
import com.agon.app.data.RelayEvent
import com.agon.app.data.StoredMessage
import com.agon.app.data.StoredPeer
import com.agon.app.data.StoredPending
import com.agon.app.data.StoredVault
import com.agon.app.data.VaultStore
import com.agon.app.data.WireEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.util.UUID
import javax.crypto.SecretKey

const val MAX_MEMBERS = 3
const val INVITE_MAX_USES = 2

private const val TOKEN_PREFIX = "BX1."
private const val PRESENCE_WINDOW_MS = 42_000L  // online if activity within ~42s (grace vs flicker)
private const val HEARTBEAT_MS = 14_000L       // presence pulse ~14s
private const val OFFLINE_GRACE_MS = 8_000L    // wait before soft-offline without explicit off

/** Disappearing messages: every message self-destructs after 3 hours. */
const val MESSAGE_TTL_MS = 3 * 60 * 60 * 1000L

/** App-open counters only count opens from the last 24 hours. */
const val OPEN_WINDOW_MS = 24 * 60 * 60 * 1000L

/** Hard cap on locally stored messages. */
const val MAX_MESSAGES = 99_999

enum class MessageStatus { SENT, DELIVERED, READ, FAILED }

data class MemberUi(
    val id: String,
    val name: String,
    val isOwner: Boolean,
    val isSelf: Boolean,
    val fingerprint: String,
    val online: Boolean,
    /** Epoch millis of last activity; 0 if never seen. */
    val lastSeenAt: Long = 0,
    /** How many times this member opened the app (owner-only display). */
    val openCount: Int = 0,
)

data class MessageUi(
    val id: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long,
    val status: MessageStatus,
    val isMine: Boolean,
    val system: Boolean = false,
    /** Names of peers who read this (own messages only). */
    val seenBy: String = "",
)

data class ChatUiState(
    val loading: Boolean = true,
    val initialized: Boolean = false,
    val joining: Boolean = false,
    val connected: Boolean = true,
    val selfId: String = "",
    val selfName: String = "",
    val isOwner: Boolean = false,
    val members: List<MemberUi> = emptyList(),
    val messages: List<MessageUi> = emptyList(),
    val typingName: String? = null,
    val audioEnabled: Boolean = true,
    val inviteToken: String? = null,
    val inviteUsesLeft: Int = 0,
    val notice: String? = null,
)

private val LINK_REGEX = Regex(
    "(https?://|wss?://|ftp://|www\\.|\\b[a-z0-9-]+\\.(com|net|org|io|co|me|ru|dev|app|xyz|gg|tv|ly|to)(/|\\b))",
    RegexOption.IGNORE_CASE,
)

/** Client-side channel guard: text only, links strictly disabled. */
fun containsLink(text: String): Boolean = LINK_REGEX.containsMatchIn(text)

/** Strip rich text / markup / control chars down to pure plaintext. */
fun sanitizePlainText(raw: String): String =
    raw.replace(Regex("<[^>]*>"), "")
        .replace(Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\u200B-\\u200F\\u202A-\\u202E]"), "")

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val store = VaultStore(app)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private var vault = StoredVault()
    private var channelKey: SecretKey? = null

    /** peerId -> last activity epoch millis (heartbeats, msgs, joins). */
    private val lastSeen = mutableMapOf<String, Long>()

    /** mid -> peerIds who sent a read receipt for that message. */
    private val messageReaders = mutableMapOf<String, MutableSet<String>>()

    /** peerId -> when they explicitly announced "pres off" (grace before offline). */
    private val offlineAnnouncedAt = mutableMapOf<String, Long>()

    private var typingClearJob: Job? = null
    private var lastTypingSentAt = 0L
    private var heartbeatCount = 0
    private var foregrounded = true

    /** Last time anything hit the wire; lets heartbeats skip when chatty. */
    @Volatile
    private var lastWireActivityAt = 0L

    /** Debounced read-receipt batching: many reads → one wire event. */
    private val pendingReadMids = java.util.Collections.synchronizedList(mutableListOf<String>())
    private var readFlushJob: Job? = null

    /** Read receipts observed while backgrounded; flushed on return. */
    private val deferredReads = mutableListOf<String>()

    /** Local tail counter for provisional ordering of unacked own messages. */
    private var localSeqTail = 0L

    /** Relay server that won the join race (seeds its stream cursor). */
    private var currentServer: String = Relay.SERVERS.first()

    /** Servers with a live stream right now; connected = any. */
    private val liveServers = java.util.Collections.synchronizedSet(mutableSetOf<String>())

    /** Bumped to force all streams to drop and reconnect immediately. */
    @Volatile
    private var streamEpoch = 0

    /** Last time each server's stream delivered anything (incl. keepalives). */
    private val streamAliveAt = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /**
     * Dedupe of processed ciphertext envelopes. Every publish has a unique
     * random IV, and mirrored copies carry the IDENTICAL envelope — so the
     * envelope string is a perfect cross-server dedupe key.
     */
    private val seenEnvelopes = object : LinkedHashMap<String, Boolean>(512, 0.75f, false) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?) = size > 800
    }

    /** Serializes live stream events (from all servers) into ordered processing. */
    private val eventChannel = kotlinx.coroutines.channels.Channel<Pair<String, RelayEvent>>(
        capacity = kotlinx.coroutines.channels.Channel.UNLIMITED
    )

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    private val topic: String get() = "brb-" + vault.boxId

    init {
        viewModelScope.launch {
            vault = store.load()
            if (vault.initialized) bootChannel()
            _state.update { it.copy(loading = false) }
            // Stream from EVERY relay server simultaneously: a message only
            // needs to land on one server for all members to receive it —
            // this closes the owner→buddy routing hole when devices happen
            // to prefer different servers.
            Relay.SERVERS.forEach { server ->
                launch { streamLoop(server) }
            }
        }
        viewModelScope.launch {
            // Drain the channel in small batches so a flood of events cannot
            // starve the main thread with one-by-one publish() storms.
            while (true) {
                val first = eventChannel.receive()
                processEvent(first.first, first.second)
                var drained = 0
                while (drained < 32) {
                    val next = eventChannel.tryReceive().getOrNull() ?: break
                    processEvent(next.first, next.second)
                    drained++
                }
                // Yield so UI frames can run between batches
                kotlinx.coroutines.yield()
            }
        }
        viewModelScope.launch { heartbeatLoop() }
        viewModelScope.launch { flushLoop() }
        viewModelScope.launch { presenceTicker() }
        viewModelScope.launch { autoDeleteLoop() }
        viewModelScope.launch { keepAliveLoop() }
    }

    /**
     * WhatsApp-style always-warm channel. Every 20s:
     *  1. Warms both servers' TCP+TLS connections (token-free health ping)
     *     so the next real send never pays a handshake — idle or not,
     *     delivery stays at one hot RTT (~100-400ms).
     *  2. Watchdog: if a stream hasn't shown life for >75s (keepalives
     *     normally arrive every ~45s), it is force-dropped and reconnected
     *     instantly instead of waiting for a timeout to surface.
     */
    private suspend fun keepAliveLoop() {
        while (true) {
            delay(if (foregrounded) 25_000 else 60_000)
            if (!vault.initialized) continue
            if (foregrounded) {
                withContext(Dispatchers.IO) { Relay.warmAll() }
            }
            val now = System.currentTimeMillis()
            val stale = liveServers.any { (now - (streamAliveAt[it] ?: now)) > 90_000 }
            if (stale) streamEpoch++ // force stream refresh
        }
    }

    /**
     * Disappearing messages: every message self-destructs 3 hours after
     * its timestamp, on every device. Checked often so expiry is reliable.
     */
    private suspend fun autoDeleteLoop() {
        while (true) {
            if (vault.initialized) purgeExpiredMessages()
            delay(15_000)
        }
    }

    /**
     * Global 3-hour disappearance cycle (NOT per-message TTL).
     * Cycle starts at the oldest non-system message timestamp. When
     * cycleStart + 3h is reached, ALL chat messages in that cycle are
     * removed together. The next message after a clear starts a new cycle.
     */
    private fun cycleStartMs(): Long =
        vault.messages.filter { !it.system }.minOfOrNull { it.timestamp } ?: 0L

    private fun purgeExpiredMessages() {
        val start = cycleStartMs()
        if (start <= 0L) return
        val now = System.currentTimeMillis()
        // Full cycle must elapse — no per-message independent expiry.
        if (now < start + MESSAGE_TTL_MS) return
        val before = vault.messages.size
        val kept = vault.messages.filter { it.system }
        if (kept.size == before) return
        messageReaders.clear()
        messagesFingerprint = ""
        cachedMessageUis = emptyList()
        vault = vault.copy(messages = kept)
        persist()
        publish()
    }

    /** True if a message timestamp still falls inside the active global cycle. */
    private fun isWithinActiveCycle(msgTs: Long): Boolean {
        val start = cycleStartMs()
        val now = System.currentTimeMillis()
        if (start <= 0L) return true // empty chat → new cycle begins on first msg
        if (now >= start + MESSAGE_TTL_MS) return false // cycle already ended
        return msgTs >= start
    }

    // ---------------------------------------------------------------- boot

    private fun bootChannel() {
        channelKey = CryptoEngine.channelKeyFromSecret(vault.channelSecret)
        // Restore persisted last-seen so "last seen" survives restarts.
        vault.lastSeenMap.forEach { (id, t) -> lastSeen[id] = maxOf(lastSeen[id] ?: 0L, t) }
        lastSeen[vault.selfId] = Long.MAX_VALUE
        // Drop open-log entries older than 24h so counts stay a rolling window.
        pruneOpenTimestamps()
        purgeExpiredMessages()
        // Re-confirm any reads we never got on the wire (crash/force-stop).
        reconcileReadReceipts()
        publish()
    }

    /** Keep only app-open timestamps inside the rolling 24-hour window. */
    private fun pruneOpenTimestamps() {
        val cutoff = System.currentTimeMillis() - OPEN_WINDOW_MS
        val pruned = vault.openTimestamps.mapValues { (_, times) ->
            times.filter { it >= cutoff }
        }.filterValues { it.isNotEmpty() }
        if (pruned != vault.openTimestamps) {
            vault = vault.copy(openTimestamps = pruned)
        }
    }

    private fun openCountFor(peerId: String): Int {
        val cutoff = System.currentTimeMillis() - OPEN_WINDOW_MS
        return vault.openTimestamps[peerId]?.count { it >= cutoff } ?: 0
    }

    private fun recordOpen(peerId: String, at: Long = System.currentTimeMillis()) {
        if (peerId.isBlank()) return
        val cutoff = at - OPEN_WINDOW_MS
        val prev = vault.openTimestamps[peerId].orEmpty().filter { it >= cutoff }
        vault = vault.copy(
            openTimestamps = vault.openTimestamps + (peerId to (prev + at)),
        )
    }

    /** Fingerprint of message list so we skip expensive decrypt on presence-only ticks. */
    private var messagesFingerprint: String = ""
    private var cachedMessageUis: List<MessageUi> = emptyList()

    private fun messagesFp(): String {
        // Message-list identity only (ignore pure presence/typing seq bumps).
        val last = vault.messages.lastOrNull()
        val statusSig = vault.messages.takeLast(12).joinToString(",") { "${it.id}:${it.status}" }
        return buildString {
            append(vault.messages.size).append('|')
            append(last?.id ?: "").append('|')
            append(last?.seq ?: 0).append('|')
            append(messageReaders.values.sumOf { it.size }).append('|')
            append(statusSig)
        }
    }


    /** Append one own message to the UI cache without re-decrypting history. */
    private fun appendOwnMessageUi(
        id: String,
        text: String,
        timestamp: Long,
        status: MessageStatus = MessageStatus.SENT,
    ) {
        val ui = MessageUi(
            id = id,
            senderId = vault.selfId,
            senderName = vault.selfName,
            text = text,
            timestamp = timestamp,
            status = status,
            isMine = true,
            system = false,
        )
        cachedMessageUis = cachedMessageUis + ui
        messagesFingerprint = messagesFp()
    }

    /** Patch statuses in the UI cache (no decrypt). Ticks only move FORWARD
     *  (SENT -> DELIVERED -> READ): a read receipt racing a send echo can
     *  never downgrade an already-blue tick back to delivered. */
    private fun patchCachedStatuses(ids: Collection<String>, status: MessageStatus) {
        if (ids.isEmpty() || cachedMessageUis.isEmpty()) return
        val idSet = ids.toSet()
        val rank = statusRank(status)
        cachedMessageUis = cachedMessageUis.map { m ->
            if (m.id in idSet && statusRank(m.status) < rank) m.copy(status = status) else m
        }
        messagesFingerprint = messagesFp()
    }

    private fun statusRank(s: MessageStatus): Int = when (s) {
        MessageStatus.FAILED -> 0
        MessageStatus.SENT -> 1
        MessageStatus.DELIVERED -> 2
        MessageStatus.READ -> 3
    }

    /** True while a peer's explicit "pres off" is still inside its grace
     *  window — we keep showing them online briefly so quick background /
     *  foreground flips don't flicker. Cleared the moment activity resumes. */
    private fun isSoftOffline(peerId: String, now: Long): Boolean {
        val offAt = offlineAnnouncedAt[peerId] ?: return false
        return now - offAt >= OFFLINE_GRACE_MS
    }

    private fun publish() {
        val now = System.currentTimeMillis()
        // Forget stale offline announcements once the presence window passes —
        // the peer is simply gone, no need to keep the flag around.
        val staleOff = offlineAnnouncedAt.entries
            .filter { (now - (lastSeen[it.key] ?: 0L)) >= PRESENCE_WINDOW_MS }
            .map { it.key }
        staleOff.forEach { offlineAnnouncedAt.remove(it) }
        val memberUis = vault.roster.map { p ->
            val seen = lastSeen[p.id] ?: 0L
            MemberUi(
                id = p.id,
                name = p.name,
                isOwner = p.isOwner,
                isSelf = p.id == vault.selfId,
                fingerprint = CryptoEngine.fingerprintB64(p.pub),
                online = p.id == vault.selfId ||
                    (!isSoftOffline(p.id, now) && (now - seen) < PRESENCE_WINDOW_MS),
                lastSeenAt = if (seen == Long.MAX_VALUE) now else minOf(seen, now),
                openCount = openCountFor(p.id),
            )
        }.sortedByDescending { it.isOwner }

        val fp = messagesFp()
        val messageUis = if (fp == messagesFingerprint && cachedMessageUis.isNotEmpty()) {
            cachedMessageUis
        } else {
            val key = channelKey
            val ordered = vault.messages.sortedWith(
                compareBy({ it.seq }, { it.timestamp }, { it.id })
            )
            val built = ordered.mapNotNull { msg ->
                if (key == null) return@mapNotNull null
                val text = runCatching { CryptoEngine.decrypt(key, msg.iv, msg.ciphertext) }.getOrNull()
                    ?: return@mapNotNull null
                MessageUi(
                    id = msg.id,
                    senderId = msg.senderId,
                    senderName = msg.senderName.ifBlank {
                        vault.roster.firstOrNull { it.id == msg.senderId }?.name ?: "Unknown"
                    },
                    text = text,
                    timestamp = msg.timestamp,
                    status = runCatching { MessageStatus.valueOf(msg.status) }.getOrDefault(MessageStatus.SENT),
                    isMine = msg.senderId == vault.selfId,
                    system = msg.system,
                    seenBy = if (msg.senderId == vault.selfId) {
                        messageReaders[msg.id].orEmpty()
                            .mapNotNull { pid -> vault.roster.firstOrNull { it.id == pid }?.name }
                            .sorted()
                            .joinToString(", ")
                    } else "",
                )
            }
            messagesFingerprint = fp
            cachedMessageUis = built
            built
        }

        _state.update {
            it.copy(
                initialized = vault.initialized,
                selfId = vault.selfId,
                selfName = vault.selfName,
                isOwner = vault.selfIsOwner,
                members = memberUis,
                messages = messageUis,
                audioEnabled = vault.audioEnabled,
                inviteToken = vault.inviteId?.let { inv -> buildToken(inv) },
                inviteUsesLeft = vault.inviteUsesLeft,
            )
        }
    }

    // Durable persistence: writes are serialized through a mutex and
    // versioned with a generation counter so a stale snapshot can NEVER
    // overwrite a newer one. The box on disk always reflects the latest
    // state and survives app restarts forever — until the owner deletes it.
    private val saveMutex = kotlinx.coroutines.sync.Mutex()
    private var saveGen = 0L

    private fun persist() {
        val snapshot = vault
        val gen = ++saveGen
        viewModelScope.launch(Dispatchers.IO) {
            saveMutex.lock()
            try {
                // Skip if a newer snapshot is already queued behind us.
                if (gen == saveGen) store.save(snapshot)
            } finally {
                saveMutex.unlock()
            }
        }
    }

    /** True only when [senderId] is the box owner known to this device. */
    private fun isFromOwner(senderId: String): Boolean {
        if (senderId.isBlank()) return false
        if (vault.selfIsOwner) return senderId == vault.selfId
        val knownOwner = vault.roster.firstOrNull { it.isOwner }?.id
        return knownOwner != null && knownOwner == senderId
    }

    // ----------------------------------------------------------- envelopes

    private fun seal(ev: WireEvent): String? {
        val key = channelKey ?: return null
        val (iv, ct) = CryptoEngine.encrypt(key, json.encodeToString(WireEvent.serializer(), ev))
        return "$iv.$ct"
    }

    private fun sealWith(key: SecretKey, ev: WireEvent): String {
        val (iv, ct) = CryptoEngine.encrypt(key, json.encodeToString(WireEvent.serializer(), ev))
        return "$iv.$ct"
    }

    private fun open(body: String, key: SecretKey? = channelKey): WireEvent? {
        val k = key ?: return null
        val dot = body.indexOf('.')
        if (dot <= 0) return null
        return runCatching {
            val plain = CryptoEngine.decrypt(k, body.substring(0, dot), body.substring(dot + 1))
            json.decodeFromString(WireEvent.serializer(), plain)
        }.getOrNull()
    }

    private fun buildToken(inviteId: String): String {
        val payload = InvitePayload(vault.boxId, vault.channelSecret, inviteId)
        val raw = json.encodeToString(InvitePayload.serializer(), payload)
        return TOKEN_PREFIX + Base64.encodeToString(
            raw.toByteArray(Charsets.UTF_8),
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING,
        )
    }

    private fun parseToken(input: String): InvitePayload? {
        var t = input.trim()
        if (t.contains("token=")) t = t.substringAfter("token=")
        t = t.trim().removeSuffix("/")
        if (!t.startsWith(TOKEN_PREFIX)) return null
        return runCatching {
            val raw = Base64.decode(
                t.removePrefix(TOKEN_PREFIX),
                Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING,
            ).toString(Charsets.UTF_8)
            json.decodeFromString(InvitePayload.serializer(), raw)
        }.getOrNull()
    }

    // ------------------------------------------------------------- outbox

    private fun enqueue(ev: WireEvent, mid: String = "") {
        val body = seal(ev) ?: return
        vault = vault.copy(pending = vault.pending + StoredPending(mid, body))
        persist()
    }

    /**
     * Fire-and-forget publish for ephemeral events (typing, heartbeats,
     * presence pings). Budget-aware: silently dropped when tokens are low
     * so background chatter can NEVER starve real messages.
     */
    private fun publishEphemeral(ev: WireEvent) {
        val body = seal(ev) ?: return
        val t = topic
        viewModelScope.launch(Dispatchers.IO) { Relay.publishEphemeralBudget(t, body) }
    }

    /**
     * Flushes queued events in order. Guarded by a mutex — previously two
     * concurrent flushes could both publish and then both shrink the queue
     * by count, silently DISCARDING messages that were never sent. Items
     * are now removed by identity, exactly the ones that were delivered,
     * with a per-item retry so one blip doesn't stall the whole queue.
     */
    private val flushMutex = kotlinx.coroutines.sync.Mutex()

    private suspend fun flushPending() {
        if (!vault.initialized || vault.pending.isEmpty()) return
        if (!flushMutex.tryLock()) return // a flush is already running
        try {
            val queue = vault.pending
            val t = topic
            val deliveredBodies = mutableSetOf<String>()
            val deliveredMids = mutableListOf<String>()
            var allSent = true
            withContext(Dispatchers.IO) {
                for (item in queue) {
                    // Parallel dual-server publish, hard-bounded — the queue
                    // can never hold the mutex for minutes anymore.
                    if (!Relay.publishFast(t, item.body)) {
                        allSent = false
                        break // preserve ordering: stop at first hard failure
                    }
                    deliveredBodies.add(item.body)
                    if (item.mid.isNotBlank()) deliveredMids.add(item.mid)
                }
            }
            if (deliveredBodies.isNotEmpty()) {
                vault = vault.copy(
                    // Remove exactly what was delivered — never by count.
                    pending = vault.pending.filterNot { it.body in deliveredBodies },
                    messages = vault.messages.map { m ->
                        if (m.id in deliveredMids && m.status in setOf(MessageStatus.SENT.name, MessageStatus.FAILED.name))
                            m.copy(status = MessageStatus.DELIVERED.name) else m
                    },
                )
                persist()
                publish()
            }
            setConnected(allSent)
        } finally {
            flushMutex.unlock()
        }
    }

    private fun setConnected(ok: Boolean) {
        if (_state.value.connected == ok) return
        _state.update { it.copy(connected = ok) }
        // Offline -> online transition (network recovered): re-announce
        // presence so peers flip us back to online immediately, instead of
        // waiting up to a heartbeat cycle. At first boot `connected` already
        // starts true, so this never duplicates the foreground announce.
        if (ok && foregrounded && vault.initialized) announceOnline()
    }

    /** Fire-and-forget "pres on" used on reconnect and app open. */
    private fun announceOnline() {
        val body = seal(
            WireEvent(
                t = "pres", senderId = vault.selfId, name = vault.selfName,
                pub = vault.selfPub, owner = vault.selfIsOwner,
                text = "on", ts = System.currentTimeMillis(),
            )
        ) ?: return
        val t = topic
        viewModelScope.launch(Dispatchers.IO) {
            lastWireActivityAt = System.currentTimeMillis()
            Relay.publishFast(t, body)
        }
    }

    // ------------------------------------------------------------ sync loop

    /**
     * Live streaming subscription for ONE relay server. Each server has
     * its own loop, cursor, and backoff; the device is "connected" while
     * at least one stream is open. Mirrored duplicates across servers are
     * dropped via envelope dedupe before processing.
     */
    private suspend fun streamLoop(server: String) {
        while (true) {
            if (!vault.initialized) {
                delay(400)
                continue
            }
            flushPending()
            val t = topic
            val epoch = streamEpoch
            val since = vault.lastEventIds[server] ?: "all"
            streamAliveAt[server] = System.currentTimeMillis()
            val ok = withContext(Dispatchers.IO) {
                Relay.stream(
                    server = server,
                    topic = t,
                    since = since,
                    isActive = {
                        // Epoch bump = watchdog/foreground demanding a fresh
                        // connection; drop out immediately.
                        vault.initialized && topic == t && streamEpoch == epoch
                    },
                    onOpen = {
                        liveServers.add(server)
                        streamAliveAt[server] = System.currentTimeMillis()
                        setConnected(true)
                    },
                    onEvent = { ev ->
                        streamAliveAt[server] = System.currentTimeMillis()
                        eventChannel.trySend(server to ev)
                    },
                )
            }
            liveServers.remove(server)
            if (!vault.initialized) continue
            if (streamEpoch != epoch) continue // deliberate refresh: reconnect NOW
            if (!ok) {
                if (liveServers.isEmpty()) setConnected(false)
                delay(1_000)
            } else {
                delay(150) // brief pause before resubscribing
            }
        }
    }

    /** Keeps the encrypted outbox draining even after transient failures. */
    private suspend fun flushLoop() {
        while (true) {
            delay(1_200)
            if (vault.initialized && vault.pending.isNotEmpty()) flushPending()
        }
    }

    private suspend fun heartbeatLoop() {
        while (true) {
            delay(HEARTBEAT_MS)
            if (!vault.initialized || !foregrounded) continue
            // Messages/receipts already prove presence — skip the heartbeat
            // when the wire has been active recently. This slashes request
            // volume during busy chat, which is what tripped rate limits.
            if (System.currentTimeMillis() - lastWireActivityAt < HEARTBEAT_MS - 2_000) continue
            heartbeatCount++
            // Heartbeats carry identity so membership self-heals: even if the
            // relay cache evicted the original join event, peers re-adopt
            // this member automatically. Membership is permanent until the
            // owner explicitly removes it.
            publishEphemeral(
                WireEvent(
                    t = "hb", senderId = vault.selfId, name = vault.selfName,
                    pub = vault.selfPub, owner = vault.selfIsOwner,
                    ts = System.currentTimeMillis(),
                )
            )
            // Owner periodically re-broadcasts the authoritative box state so
            // late joiners and returning devices converge even after the
            // relay cache evicts old events. Infrequent — every ~6 minutes.
            if (vault.selfIsOwner && heartbeatCount % 10 == 0) broadcastState()
        }
    }

    private suspend fun presenceTicker() {
        while (true) {
            delay(4_000)
            if (vault.initialized && foregrounded) {
                // Members-only refresh; message decrypt is skipped via fingerprint cache.
                publish()
            }
        }
    }

    // -------------------------------------------------- presence lifecycle

    /** Called when the user enters the chat (app foregrounded). */
    fun onAppForeground() {
        foregrounded = true
        if (!vault.initialized) return
        val now = System.currentTimeMillis()
        // Opening the app (even without messaging) marks presence + last seen.
        lastSeen[vault.selfId] = Long.MAX_VALUE
        recordOpen(vault.selfId, now)
        pruneOpenTimestamps()
        purgeExpiredMessages()
        // Instant channel revival: warm both servers and force-refresh the
        // streams so anything missed while Android throttled background
        // sockets arrives immediately — not after a stale stream times out.
        streamEpoch++
        viewModelScope.launch(Dispatchers.IO) { Relay.warmAll() }
        // Presence transitions are important — publish with retry so the
        // "online" flip lands on peers immediately and reliably.
        val onBody = seal(
            WireEvent(
                t = "pres", senderId = vault.selfId, name = vault.selfName,
                pub = vault.selfPub, owner = vault.selfIsOwner,
                text = "on", ts = now,
            )
        )
        val t = topic
        if (onBody != null) {
            viewModelScope.launch(Dispatchers.IO) {
                lastWireActivityAt = System.currentTimeMillis()
                Relay.publishFast(t, onBody)
            }
        }
        // Persist last-seen + open log so peer intel survives restarts.
        vault = vault.copy(lastSeenMap = lastSeen.filterKeys { it != vault.selfId })
        persist()
        publish()
        // Messages seen while away are read now that the user is looking.
        if (deferredReads.isNotEmpty()) {
            val reads = deferredReads.toList()
            deferredReads.clear()
            val readBody = seal(WireEvent(t = "read", senderId = vault.selfId, mids = reads))
            if (readBody != null) {
                viewModelScope.launch(Dispatchers.IO) {
                    if (!Relay.publishFast(t, readBody)) {
                        vault = vault.copy(pending = vault.pending + StoredPending("", readBody))
                        persist()
                    } else {
                        markReadsSent(reads)
                    }
                }
            }
        }
    }

    /** Called when the user leaves the chat (app backgrounded). */
    fun onAppBackground() {
        foregrounded = false
        if (!vault.initialized) return
        // Ship any pending/deferred read receipts before we go offline so
        // the peer's blue ticks stay consistent after minimize.
        flushReadsNow()
        val now = System.currentTimeMillis()
        // Precise last-seen moment when the user actually leaves the app.
        lastSeen[vault.selfId] = now
        vault = vault.copy(lastSeenMap = lastSeen.filterKeys { it != vault.selfId })
        persist()
        val offBody = seal(
            WireEvent(
                t = "pres", senderId = vault.selfId, name = vault.selfName,
                text = "off", ts = now,
            )
        )
        val t = topic
        if (offBody != null) {
            viewModelScope.launch(Dispatchers.IO) { Relay.publishFast(t, offBody) }
        }
    }

    private fun broadcastState() {
        if (!vault.selfIsOwner) return
        enqueue(
            WireEvent(
                t = "state",
                senderId = vault.selfId,
                roster = vault.roster,
                activeInvite = vault.inviteId ?: "",
                usesLeft = vault.inviteUsesLeft,
                ts = System.currentTimeMillis(),
            )
        )
    }

    // ------------------------------------------------------ event handling

    /** Entry point for live stream events; server-aware with dedupe. */
    private fun processEvent(server: String, raw: RelayEvent) {
        // Always advance this server's cursor so resumption stays correct.
        vault = vault.copy(lastEventIds = vault.lastEventIds + (server to raw.id))
        // Cross-server dedupe: mirrored copies carry the identical unique
        // ciphertext envelope — process each envelope exactly once.
        if (seenEnvelopes.put(raw.body, true) != null) {
            persist()
            return
        }
        processEvents(listOf(raw), live = true)
    }

    private fun processEvents(events: List<RelayEvent>, live: Boolean) {
        var changed = false
        var receivedSound = false
        val readReceipts = mutableListOf<String>()
        for (raw in events) {
            // Advance the global sequence for EVERY processed event — the
            // shared ordering clock all devices agree on.
            val seq = vault.seqCounter + 1
            vault = vault.copy(lastEventId = raw.id, seqCounter = seq)
            changed = true
            val ev = open(raw.body) ?: continue
            if (ev.senderId == vault.selfId && (ev.t == "msg" || ev.t == "batch")) {
                // Our own message(s) echoed back: confirm delivery only.
                // WhatsApp-style ordering — the bubble KEEPS the position it
                // had when sent; it never jumps when the echo arrives.
                val echoMids = if (ev.t == "batch") ev.batch.map { it.mid }.toSet() else setOf(ev.mid)
                vault = vault.copy(
                    messages = vault.messages.map { m ->
                        if (m.id in echoMids && !m.acked) m.copy(
                            acked = true,
                            // Never downgrade an already-READ tick.
                            status = when (m.status) {
                                MessageStatus.READ.name -> MessageStatus.READ.name
                                MessageStatus.SENT.name, MessageStatus.FAILED.name ->
                                    MessageStatus.DELIVERED.name
                                else -> m.status
                            },
                        ) else if (m.id in echoMids) m.copy(acked = true)
                        else m
                    }
                )
                patchCachedStatuses(
                    echoMids.filter { mid ->
                        vault.messages.any { it.id == mid && it.status != MessageStatus.READ.name }
                    },
                    MessageStatus.DELIVERED,
                )
                continue
            }
            if (ev.senderId == vault.selfId && ev.t != "read" && ev.t != "del") continue
            if (ev.senderId.isNotBlank()) {
                // Server clock is the shared time base; clamp so a clock-skewed
                // sender can never push last-seen into the future (fake jumps).
                val evtAt = minOf(raw.time * 1000, System.currentTimeMillis())
                lastSeen[ev.senderId] = maxOf(lastSeen[ev.senderId] ?: 0L, evtAt)
                // Any activity other than an explicit "left" proves presence.
                if (ev.t != "pres" || ev.text != "off") offlineAnnouncedAt.remove(ev.senderId)
            }
            when (ev.t) {
                "hb" -> adoptPeer(ev) // presence + membership self-healing
                "pres" -> {
                    adoptPeer(ev)
                    if (ev.text == "off") {
                        // Grace-timed offline: flag the leave + stamp last seen.
                        val offAt = (if (ev.ts > 0) ev.ts else raw.time * 1000)
                            .coerceAtMost(System.currentTimeMillis())
                        offlineAnnouncedAt[ev.senderId] = offAt
                        lastSeen[ev.senderId] = maxOf(lastSeen[ev.senderId] ?: 0L, offAt)
                    } else if (ev.text == "on") {
                        // App open (even with no message) updates last seen
                        // and counts toward the rolling 24h open counter.
                        val at = (if (ev.ts > 0) ev.ts else raw.time * 1000)
                            .coerceAtMost(System.currentTimeMillis())
                        offlineAnnouncedAt.remove(ev.senderId)
                        lastSeen[ev.senderId] = maxOf(lastSeen[ev.senderId] ?: 0L, at)
                        if (live) recordOpen(ev.senderId, at)
                    }
                }
                "join" -> handleJoin(ev)
                "state" -> handleState(ev)
                "msg" -> {
                    if (handleIncomingMessage(ev, seq)) {
                        receivedSound = true
                        if (live) {
                            // Read receipts fire only when the user is
                            // actually in the chat; otherwise deferred.
                            if (foregrounded) readReceipts.add(ev.mid)
                            else deferredReads.add(ev.mid)
                        }
                    }
                }
                "batch" -> {
                    // Multiple messages shipped in one relay request —
                    // unpack in order, preserving the sender's sequence.
                    ev.batch.forEachIndexed { bi, inner ->
                        val bEv = inner.copy(senderId = ev.senderId)
                        if (handleIncomingMessage(bEv, seq * 1000 + bi)) {
                            receivedSound = true
                            if (live) {
                                if (foregrounded) readReceipts.add(bEv.mid)
                                else deferredReads.add(bEv.mid)
                            }
                        }
                    }
                }
                "typing" -> if (live && ev.senderId != vault.selfId) showTyping(ev.name)
                "read" -> {
                    if (ev.senderId != vault.selfId && ev.mids.isNotEmpty()) {
                        for (mid in ev.mids) {
                            messageReaders.getOrPut(mid) { mutableSetOf() }.add(ev.senderId)
                        }
                        val midSet = ev.mids.toSet()
                        vault = vault.copy(
                            messages = vault.messages.map { m ->
                                if (m.id in midSet && m.senderId == vault.selfId)
                                    m.copy(status = MessageStatus.READ.name) else m
                            }
                        )
                        patchCachedStatuses(midSet, MessageStatus.READ)
                        // Force fingerprint refresh so ticks recompose immediately.
                        messagesFingerprint = ""
                        changed = true
                    }
                }
                "del" -> {
                    // Delete-for-everyone: only the original sender may remove a mid.
                    if (ev.mid.isNotBlank() && ev.senderId.isNotBlank()) {
                        val target = vault.messages.firstOrNull { it.id == ev.mid }
                        if (target != null && target.senderId == ev.senderId) {
                            vault = vault.copy(messages = vault.messages.filterNot { it.id == ev.mid })
                            messageReaders.remove(ev.mid)
                        }
                    }
                }
                "remove" -> handleRemove(ev)
                "destroy" -> {
                    // Only the owner can destroy the box. Anything else —
                    // replayed, corrupted or forged events — is ignored, so
                    // the box persists forever until the owner deletes it.
                    if (ev.senderId != vault.selfId && isFromOwner(ev.senderId)) {
                        wipe("The box was destroyed by its owner.")
                        return
                    }
                }
            }
            if (!vault.initialized) return // wiped mid-stream
        }
        if (readReceipts.isNotEmpty()) {
            // Debounced batch: rapid message bursts produce ONE receipt
            // event instead of one per message — crucial for rate limits.
            pendingReadMids.addAll(readReceipts)
            scheduleReadFlush()
        }
        if (changed) {
            // Persist last-seen so it survives restarts.
            vault = vault.copy(lastSeenMap = lastSeen.filterKeys { it != vault.selfId })
            persist()
            publish()
        }
        if (receivedSound && live && vault.audioEnabled) AudioSynth.playReceive()
    }

    /**
     * Membership is permanent: a member seen on the wire (heartbeat) who is
     * missing from the local roster — but was never explicitly removed — is
     * re-adopted silently. No fresh re-join is ever required.
     */
    private fun adoptPeer(ev: WireEvent) {
        if (ev.senderId.isBlank() || ev.senderId == vault.selfId) return
        if (ev.senderId in vault.removedIds) return
        if (vault.roster.any { it.id == ev.senderId }) return
        if (ev.name.isBlank()) return
        if (vault.roster.size >= MAX_MEMBERS) return
        vault = vault.copy(
            roster = vault.roster + StoredPeer(ev.senderId, ev.name, isOwner = ev.owner, pub = ev.pub)
        )
        if (vault.selfIsOwner) broadcastState()
    }

    private fun handleJoin(ev: WireEvent) {
        if (vault.roster.any { it.id == ev.senderId }) return          // replay dedupe
        if (ev.senderId in vault.removedIds) return                    // revoked profile
        if (vault.selfIsOwner) {
            val valid = ev.inviteId.isNotBlank() &&
                ev.inviteId == vault.inviteId &&
                vault.inviteUsesLeft > 0 &&
                vault.roster.size < MAX_MEMBERS
            if (valid) {
                val usesLeft = vault.inviteUsesLeft - 1
                val roster = vault.roster + StoredPeer(ev.senderId, ev.name, isOwner = false, pub = ev.pub)
                val exhausted = usesLeft <= 0 || roster.size >= MAX_MEMBERS
                vault = vault.copy(
                    roster = roster,
                    inviteUsesLeft = if (exhausted) 0 else usesLeft,
                    inviteId = if (exhausted) null else vault.inviteId,
                )
                addSystemMessage("${ev.name} joined the box. Keys exchanged and verified.")
                if (exhausted) addSystemMessage("Invite link self-destructed.")
            }
            // Either way, broadcast truth. An invalid joiner will see a
            // roster without themselves and self-wipe.
            broadcastState()
        } else {
            // Buddies mirror joins provisionally; the owner's next state
            // broadcast is authoritative.
            if (vault.roster.size < MAX_MEMBERS) {
                vault = vault.copy(
                    roster = vault.roster + StoredPeer(ev.senderId, ev.name, isOwner = false, pub = ev.pub)
                )
                addSystemMessage("${ev.name} joined the box.")
            }
        }
    }

    private fun handleState(ev: WireEvent) {
        if (vault.selfIsOwner) return // owner is the source of truth
        if (ev.roster.isEmpty()) return
        // Membership is permanent: a missing self entry in a roster snapshot
        // NEVER evicts this device. Only an explicit "remove" event targeting
        // this member (or a box "destroy") ends access. Merge additively and
        // keep ourselves present.
        val known = vault.roster.map { it.id }.toSet()
        val additions = ev.roster.filter { it.id !in known && it.id !in vault.removedIds }
        additions.forEach { addSystemMessage("${it.name} joined the box.") }
        var merged = vault.roster + additions
        if (merged.none { it.id == vault.selfId }) {
            merged = merged + StoredPeer(vault.selfId, vault.selfName, vault.selfIsOwner, vault.selfPub)
        }
        vault = vault.copy(roster = merged.distinctBy { it.id })
    }

    /** Returns true if a new foreign message was ingested. */
    private fun handleIncomingMessage(ev: WireEvent, seq: Long): Boolean {
        val key = channelKey ?: return false
        if (ev.mid.isBlank() || ev.senderId == vault.selfId) return false
        if (vault.messages.any { it.id == ev.mid }) return false
        if (containsLink(ev.text)) return false // channel guard, both ends
        val clean = sanitizePlainText(ev.text).trim()
        if (clean.isBlank()) return false
        // Global 3h cycle: clear finished cycles, then accept into the active
        // (or brand-new) cycle. Do not use per-message sentTime+3h expiry.
        purgeExpiredMessages()
        val msgTs = if (ev.ts > 0) ev.ts else System.currentTimeMillis()
        val start = cycleStartMs()
        if (start > 0L && msgTs < start) return false // stale pre-cycle event
        // A sender on the wire is by definition a member; self-heal roster.
        adoptPeer(ev)
        val (iv, ct) = CryptoEngine.encrypt(key, clean)
        // WhatsApp-style arrival ordering: a newly arriving message always
        // appends after everything already on screen — it can never insert
        // itself above existing bubbles.
        val maxSeq = vault.messages.maxOfOrNull { it.seq } ?: 0L
        val cappedIn = if (vault.messages.size >= MAX_MESSAGES)
            vault.messages.sortedBy { it.seq }.drop(vault.messages.size - MAX_MESSAGES + 1)
        else vault.messages
        vault = vault.copy(
            messages = cappedIn + StoredMessage(
                id = ev.mid,
                senderId = ev.senderId,
                senderName = ev.name,
                iv = iv,
                ciphertext = ct,
                timestamp = if (ev.ts > 0) ev.ts else System.currentTimeMillis(),
                seq = maxOf(seq, maxSeq + 1),
                status = MessageStatus.READ.name,
            )
        )
        typingClearJob?.cancel()
        _state.update { it.copy(typingName = null) }
        return true
    }

    private fun handleRemove(ev: WireEvent) {
        // Removals are an owner-only privilege; ignore anything else.
        if (!isFromOwner(ev.senderId)) return
        if (ev.targetId == vault.selfId) {
            wipe("Your access to this box was revoked.")
            return
        }
        val target = vault.roster.firstOrNull { it.id == ev.targetId } ?: return
        vault = vault.copy(
            roster = vault.roster.filterNot { it.id == ev.targetId },
            removedIds = vault.removedIds + ev.targetId,
        )
        addSystemMessage("${target.name} was removed. Their access profile was destroyed.")
    }

    private fun showTyping(name: String) {
        // Each new typing event extends the window — no flicker while active.
        typingClearJob?.cancel()
        if (_state.value.typingName != name) {
            _state.update { it.copy(typingName = name) }
        } else {
            // same name: keep visible without redundant state writes
            _state.update { it.copy(typingName = name) }
        }
        typingClearJob = viewModelScope.launch {
            delay(5_000)
            _state.update { s -> if (s.typingName == name) s.copy(typingName = null) else s }
        }
    }

    // ---------------------------------------------------------------- gate

    /** Owner claims the box: mints the channel + ECDH identity on-device. */
    fun claimBox(name: String) {
        if (vault.initialized) return
        val clean = sanitizePlainText(name).trim().take(24)
        if (clean.isBlank()) return
        val kp = CryptoEngine.generateKeyPair()
        val selfId = UUID.randomUUID().toString()
        val pub = CryptoEngine.encodePublic(kp.public)
        vault = StoredVault(
            initialized = true,
            boxId = CryptoEngine.randomId(10),
            channelSecret = CryptoEngine.newChannelSecret(),
            selfId = selfId,
            selfName = clean,
            selfIsOwner = true,
            selfPub = pub,
            selfPriv = CryptoEngine.encodePrivate(kp.private),
            roster = listOf(StoredPeer(selfId, clean, isOwner = true, pub = pub)),
            joinedAt = System.currentTimeMillis(),
        )
        bootChannel()
        addSystemMessage("$clean sealed this box. End-to-end encryption active.")
        addSystemMessage("Disappearing messages: everything self-destructs after 3 hours.")
        enqueue(
            WireEvent(t = "join", senderId = selfId, name = clean, pub = pub, ts = System.currentTimeMillis())
        )
        broadcastState()
        persist()
        publish()
    }

    // ------------------------------------------------------------- invites

    /** Owner-only. Mints a self-contained token valid for exactly 2 joins. */
    fun generateInvite(): Boolean {
        if (!vault.initialized || !vault.selfIsOwner) return false
        if (vault.roster.size >= MAX_MEMBERS) {
            notice("Box is at full capacity (3/3). Invites are sealed.")
            return false
        }
        val inviteId = CryptoEngine.newInviteToken()
        val uses = minOf(INVITE_MAX_USES, MAX_MEMBERS - vault.roster.size)
        vault = vault.copy(inviteId = inviteId, inviteUsesLeft = uses)
        broadcastState()
        persist()
        publish()
        return true
    }

    fun revokeInvite() {
        if (!vault.selfIsOwner) return
        vault = vault.copy(inviteId = null, inviteUsesLeft = 0)
        broadcastState()
        persist()
        publish()
        notice("Invite link destroyed.")
    }

    /**
     * Invite validation engine, now fully cross-device:
     * the token itself carries the box id + channel secret, and validation
     * runs against the real shared box history pulled from the relay — no
     * prior connection with the owner's device is required.
     */
    fun redeemInvite(tokenInput: String, buddyName: String) {
        val name = sanitizePlainText(buddyName).trim().take(24)
        if (name.isBlank()) {
            notice("A codename is required.")
            return
        }
        val payload = parseToken(tokenInput)
        if (payload == null) {
            notice("Invalid or expired invite token.")
            return
        }
        if (_state.value.joining) return
        _state.update { it.copy(joining = true) }

        viewModelScope.launch {
            val key = CryptoEngine.channelKeyFromSecret(payload.secret)
            val t = "brb-" + payload.boxId
            // MERGED validation fetch: both relay servers are queried in
            // parallel and their histories UNIONED (deduped, time-ordered).
            // Mirroring is best-effort, so one server alone may be missing
            // the owner's latest invite state — validating against a single
            // server caused false "expired token" verdicts. The union always
            // contains the freshest state either server has.
            val fetched = withContext(Dispatchers.IO) {
                Relay.pollMerged(t, "all") ?: Relay.pollMerged(t, "all")
            }
            if (fetched == null) {
                _state.update { it.copy(joining = false) }
                notice("Couldn't reach the box. Check your internet and try again.")
                return@launch
            }
            val (serverCursors, history) = fetched
            val events = history.mapNotNull { raw -> open(raw.body, key)?.let { raw to it } }
            // If we reached the relays but the box has no history at all,
            // the invite can't be validated — tell the truth, fast.
            if (events.isEmpty()) {
                _state.update { it.copy(joining = false) }
                notice("Box not found. Ask the owner for a fresh invite link.")
                return@launch
            }

            // ---- validate against the real shared history ----
            if (events.any { it.second.t == "destroy" }) {
                _state.update { it.copy(joining = false) }
                notice("Invalid or expired invite token.")
                return@launch
            }
            val latestState = events.filter { it.second.t == "state" }.maxByOrNull { it.second.ts }?.second
            val joinsWithInvite = events.count {
                it.second.t == "join" && it.second.inviteId == payload.inviteId
            }
            val roster: List<StoredPeer> = latestState?.roster ?: buildList {
                events.filter { it.second.t == "join" }.forEach { (_, j) ->
                    if (none { it.id == j.senderId }) {
                        add(StoredPeer(j.senderId, j.name, isOwner = j.inviteId.isBlank(), pub = j.pub))
                    }
                }
                events.filter { it.second.t == "remove" }.forEach { (_, r) ->
                    removeAll { it.id == r.targetId }
                }
            }
            val inviteRevoked = latestState != null && latestState.activeInvite != payload.inviteId
            val usesLeft = latestState?.usesLeft ?: (INVITE_MAX_USES - joinsWithInvite)
            val failReason = when {
                roster.size >= MAX_MEMBERS -> "Access denied. This box is permanently full."
                inviteRevoked || usesLeft <= 0 -> "Invalid or expired invite token."
                roster.any { it.name.equals(name, ignoreCase = true) } ->
                    "That codename is already inside the box."
                else -> null
            }
            if (failReason != null) {
                _state.update { it.copy(joining = false) }
                notice(failReason)
                return@launch
            }

            // ---- join: mint identity, announce, adopt the box ----
            val kp = CryptoEngine.generateKeyPair()
            val selfId = UUID.randomUUID().toString()
            val pub = CryptoEngine.encodePublic(kp.public)
            val joinBody = sealWith(
                key,
                WireEvent(
                    t = "join", senderId = selfId, name = name, pub = pub,
                    inviteId = payload.inviteId, ts = System.currentTimeMillis(),
                ),
            )
            // One-tap reliability: the announce races both servers in
            // parallel (fastest wins), with interleaved retries as fallback.
            val announced = withContext(Dispatchers.IO) {
                Relay.publishFast(t, joinBody) || Relay.publishWithRetry(t, joinBody, attempts = 3)
            }
            if (!announced) {
                _state.update { it.copy(joining = false) }
                notice("Couldn't reach the box after several tries. Please try again.")
                return@launch
            }
            vault = StoredVault(
                initialized = true,
                boxId = payload.boxId,
                channelSecret = payload.secret,
                selfId = selfId,
                selfName = name,
                selfIsOwner = false,
                selfPub = pub,
                selfPriv = CryptoEngine.encodePrivate(kp.private),
                roster = roster + StoredPeer(selfId, name, isOwner = false, pub = pub),
                joinedAt = System.currentTimeMillis(),
                lastEventId = history.lastOrNull()?.id ?: "",
                lastEventIds = serverCursors,
            )
            serverCursors.keys.firstOrNull()?.let { currentServer = it }
            // Seed the dedupe so mirrored copies of the replayed history
            // (arriving via the second server's stream) are not reprocessed.
            history.forEach { seenEnvelopes.put(it.body, true) }
            bootChannel()
            // Replay encrypted history in relay order, assigning each event
            // its global sequence number so this device sorts the
            // conversation identically to every other member.
            val eventSeq = history.withIndex().associate { (i, raw) -> raw.id to (i + 1).toLong() }
            vault = vault.copy(seqCounter = history.size.toLong())
            events.forEach { (raw, ev) ->
                if (ev.t == "msg") {
                    handleIncomingMessage(ev, eventSeq[raw.id] ?: 0L)
                    lastSeen[ev.senderId] = maxOf(lastSeen[ev.senderId] ?: 0L, raw.time * 1000)
                } else if (ev.t == "batch") {
                    val base = (eventSeq[raw.id] ?: 0L) * 1000
                    ev.batch.forEachIndexed { bi, inner ->
                        handleIncomingMessage(inner.copy(senderId = ev.senderId), base + bi)
                    }
                    lastSeen[ev.senderId] = maxOf(lastSeen[ev.senderId] ?: 0L, raw.time * 1000)
                }
            }
            addSystemMessage("You joined the box. Keys exchanged and verified.")
            persist()
            publish()
            _state.update { it.copy(joining = false) }
            if (vault.audioEnabled) AudioSynth.playReceive()
        }
    }

    /** Owner-only. Deletes the profile and revokes the session on B's device. */
    fun removeBuddy(memberId: String) {
        if (!vault.selfIsOwner) return
        val target = vault.roster.firstOrNull { it.id == memberId } ?: return
        if (target.isOwner) return
        vault = vault.copy(
            roster = vault.roster.filterNot { it.id == memberId },
            removedIds = vault.removedIds + memberId,
        )
        addSystemMessage("${target.name} was removed. Their access profile was destroyed and session revoked.")
        enqueue(WireEvent(t = "remove", senderId = vault.selfId, targetId = memberId))
        broadcastState()
        persist()
        publish()
    }

    // ------------------------------------------------------------ messages

    /**
     * Delete-for-everyone. Removes the bubble on this device immediately and
     * broadcasts a sealed "del" so every peer drops the same mid. Only the
     * original sender can delete their own messages.
     */
    fun deleteMessage(mid: String) {
        if (!vault.initialized || mid.isBlank()) return
        val target = vault.messages.firstOrNull { it.id == mid } ?: return
        if (target.senderId != vault.selfId || target.system) return
        vault = vault.copy(messages = vault.messages.filterNot { it.id == mid })
        messageReaders.remove(mid)
        // Drop from unsent outbox if still queued.
        synchronized(sendOutbox) {
            sendOutbox.removeAll { it.mid == mid }
        }
        persist()
        publish()
        val body = seal(
            WireEvent(t = "del", senderId = vault.selfId, mid = mid, ts = System.currentTimeMillis())
        )
        val t = topic
        if (body != null) {
            viewModelScope.launch(Dispatchers.IO) {
                lastWireActivityAt = System.currentTimeMillis()
                if (!Relay.publishFast(t, body)) {
                    vault = vault.copy(pending = vault.pending + StoredPending(mid, body))
                    persist()
                }
            }
        }
    }

    /**
     * Seals plaintext with AES-GCM-256 and queues the ciphertext envelope
     * for the relay. Offline-safe: queued envelopes auto-send on reconnect.
     */
    fun sendMessage(raw: String): Boolean {
        val key = channelKey ?: return false
        if (!vault.initialized) return false
        val text = sanitizePlainText(raw).trim()
        if (text.isBlank()) return false
        if (containsLink(text)) {
            notice("Links and media are strictly disabled.")
            return false
        }
        val mid = UUID.randomUUID().toString()
        val ts = System.currentTimeMillis()
        val (iv, ct) = CryptoEngine.encrypt(key, text)
        // WhatsApp-style: the message takes the bottom slot at send time and
        // keeps it forever — the sequence is final immediately, so the
        // bubble never reorders or jumps when the relay confirms it.
        localSeqTail++
        // Final sequence: strictly after everything currently on screen.
        val maxSeq = vault.messages.maxOfOrNull { it.seq } ?: 0L
        val finalSeq = maxOf(vault.seqCounter, maxSeq) + localSeqTail
        // Capacity: keep up to MAX_MESSAGES locally, trimming the oldest.
        val capped = if (vault.messages.size >= MAX_MESSAGES)
            vault.messages.sortedBy { it.seq }.drop(vault.messages.size - MAX_MESSAGES + 1)
        else vault.messages
        vault = vault.copy(
            messages = capped + StoredMessage(
                id = mid,
                senderId = vault.selfId,
                senderName = vault.selfName,
                iv = iv,
                ciphertext = ct,
                timestamp = ts,
                seq = finalSeq,
                status = MessageStatus.SENT.name,
            )
        )
        // Optimistic UI: show bubble instantly with plaintext (no full re-decrypt).
        appendOwnMessageUi(mid, text, ts, MessageStatus.SENT)
        publish()
        persist()
        if (vault.audioEnabled) AudioSynth.playSend()
        hapticSend()
        typingClearJob?.cancel()
        _state.update { it.copy(typingName = null) }

        // Adaptive batching outbox: decouples MESSAGES from REQUESTS, the
        // key to WhatsApp-grade sustained throughput. When budget is rich
        // the message ships alone instantly (~1 RTT). Under rapid fire or a
        // thinning budget, messages coalesce so many messages cost ONE
        // relay request. Sustained chatting can never outrun the rate
        // limit, so message #122 is as fast as message #1.
        synchronized(sendOutbox) {
            sendOutbox.add(
                WireEvent(
                    t = "msg", senderId = vault.selfId, name = vault.selfName,
                    mid = mid, text = text, ts = ts,
                )
            )
        }
        scheduleSendFlush()
        return true
    }

    /** Outbox of unsent message events; coalesced into batch publishes. */
    private val sendOutbox = mutableListOf<WireEvent>()
    private var sendFlushJob: Job? = null

    private fun scheduleSendFlush() {
        if (sendFlushJob?.isActive == true) return
        sendFlushJob = viewModelScope.launch {
            // Instant delivery: ship immediately when budget allows.
            // Tiny coalesce only under rate pressure so bursts stay one request.
            // Always ship immediately — rate limit handled by relay/batch path.
            val window = 0L
            if (window > 0) delay(window)
            val eventsToSend: List<WireEvent>
            synchronized(sendOutbox) {
                eventsToSend = sendOutbox.toList()
                sendOutbox.clear()
            }
            if (eventsToSend.isEmpty()) return@launch
            // 1 message -> plain msg event; N messages -> ONE batch event.
            val wireEvent = if (eventsToSend.size == 1) eventsToSend.first()
            else WireEvent(t = "batch", senderId = vault.selfId, batch = eventsToSend)
            val wire = seal(wireEvent) ?: return@launch
            val mids = eventsToSend.map { it.mid }
            val t = topic
            withContext(Dispatchers.IO) {
                lastWireActivityAt = System.currentTimeMillis()
                val ok = Relay.publishFast(t, wire) || Relay.publishFast(t, wire)
                if (ok) {
                    setConnected(true)
                    vault = vault.copy(
                        messages = vault.messages.map { m ->
                            if (m.id in mids && m.status in setOf(MessageStatus.SENT.name, MessageStatus.FAILED.name))
                                m.copy(status = MessageStatus.DELIVERED.name) else m
                        }
                    )
                    patchCachedStatuses(mids, MessageStatus.DELIVERED)
                    persist()
                    publish()
                } else {
                    // Offline fallback: queue durably + mark bubbles failed for UI.
                    setConnected(false)
                    vault = vault.copy(
                        pending = vault.pending + StoredPending(mids.firstOrNull() ?: "", wire),
                        messages = vault.messages.map { m ->
                            if (m.id in mids && m.status == MessageStatus.SENT.name)
                                m.copy(status = MessageStatus.FAILED.name) else m
                        },
                    )
                    persist()
                    publish()
                }
            }
            // More arrived while flushing? Go again immediately.
            val more = synchronized(sendOutbox) { sendOutbox.isNotEmpty() }
            if (more) scheduleSendFlush()
        }
    }

    /**
     * Fast read-receipt sender. Drains the queue in a loop so rapid bursts
     * and minimize/restore never leave mids stuck without a "seen" tick.
     */
    private fun scheduleReadFlush() {
        if (readFlushJob?.isActive == true) return
        readFlushJob = viewModelScope.launch {
            while (true) {
                delay(80)
                val mids: List<String>
                synchronized(pendingReadMids) {
                    mids = pendingReadMids.distinct()
                    pendingReadMids.clear()
                }
                if (mids.isEmpty()) break
                val wire = seal(WireEvent(t = "read", senderId = vault.selfId, mids = mids))
                    ?: continue
                val topicId = topic
                val sent = withContext(Dispatchers.IO) {
                    lastWireActivityAt = System.currentTimeMillis()
                    if (!Relay.publishFast(topicId, wire)) {
                        vault = vault.copy(pending = vault.pending + StoredPending("", wire))
                        persist()
                        false
                    } else true
                }
                if (sent) markReadsSent(mids)
                // Loop again — more mids may have arrived during publish.
            }
        }
    }

    /** Immediate drain used on background so receipts aren't lost. */
    private fun flushReadsNow() {
        val mids: List<String>
        synchronized(pendingReadMids) {
            mids = (pendingReadMids + deferredReads).distinct()
            pendingReadMids.clear()
        }
        deferredReads.clear()
        if (mids.isEmpty()) return
        val wire = seal(WireEvent(t = "read", senderId = vault.selfId, mids = mids)) ?: return
        val topicId = topic
        viewModelScope.launch(Dispatchers.IO) {
            lastWireActivityAt = System.currentTimeMillis()
            if (!Relay.publishFast(topicId, wire)) {
                vault = vault.copy(pending = vault.pending + StoredPending("", wire))
                persist()
            } else {
                markReadsSent(mids)
            }
        }
    }


    /**
     * Durable read-receipt ledger + reconciliation. Confirms are recorded so
     * a process death mid-rapid-chat (or a force-stop) never loses a blue
     * tick: on the next boot we re-send the most recent unconfirmed reads.
     */
    private fun markReadsSent(mids: List<String>) {
        if (mids.isEmpty()) return
        val merged = (vault.readReceiptsSent + mids).distinct()
        vault = vault.copy(readReceiptsSent = merged.takeLast(500))
        persist()
    }

    private fun reconcileReadReceipts() {
        if (!vault.initialized) return
        val live = vault.messages.map { it.id }.toSet()
        val kept = vault.readReceiptsSent.filter { it in live }.takeLast(500)
        if (kept.size != vault.readReceiptsSent.size) {
            vault = vault.copy(readReceiptsSent = kept)
            persist()
        }
        val sentSet = kept.toSet()
        val unconfirmed = vault.messages
            .asSequence()
            .filter {
                it.senderId != vault.selfId &&
                    it.status == MessageStatus.READ.name &&
                    it.id !in sentSet
            }
            .map { it.id }
            .take(120)
            .toList()
        if (unconfirmed.isEmpty()) return
        viewModelScope.launch {
            delay(900) // let streams connect first
            val body = seal(WireEvent(t = "read", senderId = vault.selfId, mids = unconfirmed))
                ?: return@launch
            val t = topic
            val ok = withContext(Dispatchers.IO) {
                lastWireActivityAt = System.currentTimeMillis()
                Relay.publishFast(t, body)
            }
            if (ok) markReadsSent(unconfirmed)
            else {
                vault = vault.copy(pending = vault.pending + StoredPending("", body))
                persist()
            }
        }
    }

    /**
     * Throttled live typing broadcast. Budget-aware and low-priority:
     * typing pings are dropped entirely when tokens run low — they are
     * pure decoration and must never consume a real message's budget.
     */
    fun onTyping() {
        if (!vault.initialized) return
        val now = System.currentTimeMillis()
        if (now - lastTypingSentAt < 2_500) return
        lastTypingSentAt = now
        publishEphemeral(WireEvent(t = "typing", senderId = vault.selfId, name = vault.selfName, ts = now))
    }

    private fun addSystemMessage(text: String) {
        val key = channelKey ?: return
        val (iv, ct) = CryptoEngine.encrypt(key, text)
        vault = vault.copy(
            messages = vault.messages + StoredMessage(
                id = UUID.randomUUID().toString(),
                senderId = vault.selfId,
                senderName = vault.selfName,
                iv = iv,
                ciphertext = ct,
                timestamp = System.currentTimeMillis(),
                seq = vault.seqCounter,
                status = MessageStatus.READ.name,
                system = true,
            )
        )
    }

    // ------------------------------------------------------------ ambient

    fun toggleAudio() {
        vault = vault.copy(audioEnabled = !vault.audioEnabled)
        persist()
        publish()
    }

    /** Light haptic feedback on successful local send. */
    private fun hapticSend() {
        try {
            val v = getApplication<Application>().getSystemService(android.content.Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (v != null && v.hasVibrator()) {
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(android.os.VibrationEffect.createOneShot(18, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(18)
                }
            }
        } catch (_: Exception) { }
    }

    fun notice(message: String) {
        _state.update { it.copy(notice = message) }
    }

    fun clearNotice() {
        _state.update { it.copy(notice = null) }
    }

    /** Owner: nukes the box for everyone. Buddy: leaves and wipes locally. */
    fun destroyBox() {
        if (vault.selfIsOwner && vault.initialized) {
            val body = seal(WireEvent(t = "destroy", senderId = vault.selfId, ts = System.currentTimeMillis()))
            val t = topic
            if (body != null) {
                viewModelScope.launch(Dispatchers.IO) { Relay.publish(t, body) }
            }
        }
        wipe(null)
    }

    private fun wipe(reason: String?) {
        typingClearJob?.cancel()
        readFlushJob?.cancel()
        sendFlushJob?.cancel()
        synchronized(sendOutbox) { sendOutbox.clear() }
        pendingReadMids.clear()
        vault = StoredVault()
        channelKey = null
        lastSeen.clear()
        messageReaders.clear()
        messagesFingerprint = ""
        cachedMessageUis = emptyList()
        offlineAnnouncedAt.clear()
        deferredReads.clear()
        seenEnvelopes.clear()
        liveServers.clear()
        localSeqTail = 0L
        persist()
        _state.update { ChatUiState(loading = false, notice = reason) }
    }
}
