package com.agon.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkChatScheme = darkColorScheme(
    primary = Coral,
    onPrimary = InkLight,
    secondary = MutedGray,
    onSecondary = InkLight,
    tertiary = ReadBlue,
    background = ChatBg,
    onBackground = InkLight,
    surface = HeaderBg,
    onSurface = InkLight,
    surfaceVariant = SurfaceDark,
    onSurfaceVariant = MutedGray,
    outline = SurfaceBorder,
    outlineVariant = SurfaceBorder,
    error = DangerRed,
    onError = InkLight,
)

@Composable
fun AgonAppTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkChatScheme,
        content = content,
    )
}
