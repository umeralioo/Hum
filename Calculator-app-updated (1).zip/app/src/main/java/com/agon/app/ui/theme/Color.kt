package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

// Screenshot reference: charcoal + deep red + dark grey bubbles
val ChatBg = Color(0xFF0B0B0E)
val ChatBgTop = Color(0xFF121216)
val HeaderBg = Color(0xFF0E0E12)
val SurfaceDark = Color(0xFF18181C)
val SurfaceBorder = Color(0xFF2A2A32)

// Sent = dark grey (right) — white text
val SentBubble = Color(0xFF1F1F25)
val SentBubbleTop = Color(0xFF2D2D35)
val SentMeta = Color(0xFF8E8E93)
val SentText = Color(0xFFFFFFFF)

// Received = deep red (left) — white text
val RecvBubble = Color(0xFF800E1A)
val RecvBubbleTop = Color(0xFFA81928)
val RecvBubbleDeep = Color(0xFF4D050D)
val RecvMeta = Color(0xFFD08088)

val AvatarRed = Color(0xFF7A1420)
val AvatarRedDeep = Color(0xFF3B080F)

val InkLight = Color(0xFFFFFFFF)
val MutedGray = Color(0xFF8E8E93)
val DimGray = Color(0xFF6E6E78)

val ReadBlue = Color(0xFF0099FF)
val OnlineGreen = Color(0xFF25D366)
val DangerRed = Color(0xFFEF4444)
val Coral = Color(0xFFA81928)
val Gold = Color(0xFFE07A5F)
val SendBtnRed = Color(0xFFA81928)

// Aliases
val Cream = ChatBg
val CreamLine = SurfaceBorder
val CreamBorder = SurfaceBorder
val Paper = HeaderBg
val Ink = InkLight
val Muted = MutedGray
val CoralSoft = RecvMeta
val SentGreen = SentBubble
val SentGreenSoft = SentMeta
val AvatarOrange = AvatarRed
val Obsidian = ChatBg
val Zinc = SurfaceDark
val ZincHigh = Color(0xFF1C1C22)
val ZincBorder = SurfaceBorder
val BrightWhite = InkLight
val SoftGray = MutedGray
val GoldDim = Color(0xFF8A2028)
