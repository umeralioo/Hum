package com.agon.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.round

/**
 * Launcher decoy: a fully working calculator. The real app opens only when
 * the hidden sequence "+++++" is entered and "=" is pressed. All other
 * input behaves like a normal calculator so the disguise holds.
 * Secret unlock: press ÷ five times, then = .
 */
class CalculatorLockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CalculatorLockScreen(
                    onUnlock = {
                        startActivity(Intent(this, MainActivity::class.java))
                        @Suppress("DEPRECATION")
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        finish()
                    },
                )
            }
        }
    }
}

// Built at runtime so a plain string search is less obvious in the APK.
private val UNLOCK_CODE: String = buildString { repeat(5) { append('÷') } }

@Composable
private fun CalculatorLockScreen(onUnlock: () -> Unit) {
    var display by remember { mutableStateOf("0") }
    var accumulator by remember { mutableStateOf<Double?>(null) }
    var pendingOp by remember { mutableStateOf<String?>(null) }
    var typingFresh by remember { mutableStateOf(true) }
    var keySeq by remember { mutableStateOf("") }

    fun formatNumber(n: Double): String {
        if (n.isNaN() || n.isInfinite()) return "Error"
        val rounded = round(n * 1_000_000_000.0) / 1_000_000_000.0
        return if (rounded == rounded.toLong().toDouble()) {
            rounded.toLong().toString()
        } else {
            val s = rounded.toString()
            s.trimEnd('0').trimEnd('.')
        }
    }

    fun applyOp(op: String, a: Double, b: Double): Double = when (op) {
        "+" -> a + b
        "−", "-" -> a - b
        "×", "*" -> a * b
        "÷", "/" -> if (b == 0.0) Double.NaN else a / b
        "%" -> a % b
        else -> b
    }

    fun trackKey(label: String) {
        keySeq = (keySeq + label).takeLast(8)
    }

    fun clearAll() {
        display = "0"
        accumulator = null
        pendingOp = null
        typingFresh = true
        keySeq = ""
    }

    fun inputDigit(d: String) {
        trackKey(d)
        if (typingFresh) {
            display = d
            typingFresh = false
        } else {
            if (d == "." && display.contains('.')) return
            if (display == "0" && d != ".") display = d
            else if (display.length < 14) display += d
        }
    }

    fun inputOp(op: String) {
        trackKey(op)
        val current = display.toDoubleOrNull() ?: return
        val acc = accumulator
        val pop = pendingOp
        if (acc != null && pop != null && !typingFresh) {
            val result = applyOp(pop, acc, current)
            display = formatNumber(result)
            accumulator = if (result.isNaN()) null else result
        } else {
            accumulator = current
        }
        pendingOp = op
        typingFresh = true
    }

    fun percent() {
        trackKey("%")
        val current = display.toDoubleOrNull() ?: return
        val value = if (accumulator != null && pendingOp != null) {
            // iOS-style: percent of accumulator
            accumulator!! * (current / 100.0)
        } else {
            current / 100.0
        }
        display = formatNumber(value)
        typingFresh = true
    }

    fun equals() {
        // Hidden unlock: five consecutive "÷" then "="
        if (keySeq.contains(UNLOCK_CODE) || display == UNLOCK_CODE) {
            onUnlock()
            return
        }
        trackKey("=")
        val current = display.toDoubleOrNull()
        val acc = accumulator
        val pop = pendingOp
        if (current != null && acc != null && pop != null) {
            val result = applyOp(pop, acc, current)
            display = formatNumber(result)
            accumulator = null
            pendingOp = null
        }
        typingFresh = true
        keySeq = ""
    }

    fun backspace() {
        trackKey("⌫")
        if (typingFresh) return
        display = if (display.length > 1) display.dropLast(1) else "0"
        if (display == "0") typingFresh = true
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF111111)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.Bottom,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.BottomEnd,
            ) {
                Text(
                    text = display,
                    color = Color.White,
                    fontSize = if (display.length > 9) 40.sp else 56.sp,
                    fontWeight = FontWeight.Light,
                    maxLines = 2,
                )
            }

            val rows = listOf(
                listOf("C", "⌫", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "−"),
                listOf("1", "2", "3", "+"),
                listOf("0", ".", "="),
            )

            rows.forEach { row ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    row.forEach { label ->
                        val keyWeight = if (label == "0") 2f else 1f
                        CalcKey(
                            label = label,
                            modifier = Modifier
                                .weight(keyWeight)
                                .aspectRatio(if (label == "0") 2f else 1f),
                            onClick = {
                                when (label) {
                                    "C" -> clearAll()
                                    "⌫" -> backspace()
                                    "=" -> equals()
                                    "%" -> percent()
                                    "÷", "×", "−", "+" -> inputOp(label)
                                    else -> inputDigit(label)
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.CalcKey(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val isOperator = label == "÷" || label == "×" || label == "−" || label == "+" || label == "="
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isOperator) Color(0xFFFF9F0A) else Color(0xFF333333),
            contentColor = Color.White,
        ),
        contentPadding = PaddingValues(0.dp),
    ) {
        Text(text = label, fontSize = 24.sp)
    }
}
