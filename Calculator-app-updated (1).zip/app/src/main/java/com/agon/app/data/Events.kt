package com.agon.app.data

import kotlinx.serialization.Serializable

/**
 * Wire protocol. Every one of these events is serialized to JSON and then
 * sealed with the AES-GCM-256 channel key before it ever leaves the
 * device. The relay only sees "<ivB64>.<ctB64>" blobs.
 */
@Serializable
data class WireEvent(
    val t: String,                                  // hb|join|state|msg|typing|read|remove|destroy|del|batch|pres
    val senderId: String = "",
    val name: String = "",
    val pub: String = "",
    val inviteId: String = "",
    val mid: String = "",
    val text: String = "",
    val ts: Long = 0,
    val targetId: String = "",
    val mids: List<String> = emptyList(),
    val roster: List<StoredPeer> = emptyList(),
    val usesLeft: Int = 0,
    val activeInvite: String = "",
    val owner: Boolean = false,
    /** t="batch": multiple msg events shipped in ONE relay request. */
    val batch: List<WireEvent> = emptyList(),
)

@Serializable
data class InvitePayload(
    val boxId: String,
    val secret: String,
    val inviteId: String,
)
