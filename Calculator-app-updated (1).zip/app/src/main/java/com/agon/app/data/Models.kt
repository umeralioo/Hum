package com.agon.app.data

import kotlinx.serialization.Serializable

/**
 * Zero-knowledge storage schema. The vault persists ONLY:
 *  - this device's own key material
 *  - peer public keys (needed for fingerprints)
 *  - ciphertext + IV pairs for every message
 * No plaintext ever touches disk, and the relay only ever sees ciphertext.
 */

@Serializable
data class StoredPeer(
    val id: String,
    val name: String,
    val isOwner: Boolean,
    val pub: String = "",
)

@Serializable
data class StoredMessage(
    val id: String,
    val senderId: String,
    val senderName: String = "",
    val iv: String,
    val ciphertext: String,
    val timestamp: Long,
    /** Monotonic ordering key derived from the relay's global event order. */
    val seq: Long = 0,
    /** True once the relay echo locked in the final global sequence. */
    val acked: Boolean = false,
    val status: String,
    val system: Boolean = false,
)

/** An outbound event waiting for the relay (offline queue). */
@Serializable
data class StoredPending(
    val mid: String = "",
    val body: String,
)

@Serializable
data class StoredVault(
    val initialized: Boolean = false,
    val audioEnabled: Boolean = true,
    val boxId: String = "",
    val channelSecret: String = "",
    val selfId: String = "",
    val selfName: String = "",
    val selfIsOwner: Boolean = false,
    val selfPub: String = "",
    val selfPriv: String = "",
    val roster: List<StoredPeer> = emptyList(),
    val removedIds: List<String> = emptyList(),
    val inviteId: String? = null,
    val inviteUsesLeft: Int = 0,
    val messages: List<StoredMessage> = emptyList(),
    val pending: List<StoredPending> = emptyList(),
    val lastEventId: String = "",
    /** Per-relay-server cursor of the last processed event id. */
    val lastEventIds: Map<String, String> = emptyMap(),
    val joinedAt: Long = 0,
    /** Count of relay events processed; drives message ordering. */
    val seqCounter: Long = 0,
    /** peerId -> last seen epoch millis, persisted across restarts. */
    val lastSeenMap: Map<String, Long> = emptyMap(),
    /**
     * peerId -> epoch millis of each app-open event (pres "on").
     * Open counts are derived from the last 24 hours of this log.
     */
    val openTimestamps: Map<String, List<Long>> = emptyMap(),
    /**
     * mids of RECEIVED messages we already confirmed READ on the wire.
     * Durable, so peers' blue ticks are never lost across process death,
     * force-stop or missed receipts.
     */
    val readReceiptsSent: List<String> = emptyList(),
)
