package com.agon.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.viewmodel.ChatViewModel
import com.agon.app.ui.theme.Coral
import com.agon.app.ui.theme.Cream
import com.agon.app.ui.theme.CreamBorder
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.Ink
import com.agon.app.ui.theme.Muted
import com.agon.app.ui.theme.Obsidian
import com.agon.app.ui.theme.Paper
import com.agon.app.ui.theme.SoftGray
import com.agon.app.ui.theme.Zinc

private enum class GateMode { RESTRICTED, CLAIM, REDEEM }

/**
 * Zero-discoverability gate. Uninvited visitors see only "Access
 * Restricted" with zero operational feedback. Tapping the seal reveals
 * the claim / invite paths.
 */
@Composable
fun GateScreen(vm: ChatViewModel) {
    var mode by remember { mutableStateOf(GateMode.RESTRICTED) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Cream),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = mode,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "gate",
        ) { current ->
            when (current) {
                GateMode.RESTRICTED -> RestrictedPanel(
                    onClaim = { mode = GateMode.CLAIM },
                    onRedeem = { mode = GateMode.REDEEM },
                )
                GateMode.CLAIM -> ClaimPanel(vm, onBack = { mode = GateMode.RESTRICTED })
                GateMode.REDEEM -> RedeemPanel(vm, onBack = { mode = GateMode.RESTRICTED })
            }
        }
    }
}

@Composable
private fun RestrictedPanel(onClaim: () -> Unit, onRedeem: () -> Unit) {
    var taps by remember { mutableStateOf(0) }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(32.dp),
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Paper)
                .border(1.dp, CreamBorder, RoundedCornerShape(24.dp))
                .clickable { taps++ },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Default.Lock,
                contentDescription = null,
                tint = Muted,
                modifier = Modifier.size(36.dp),
            )
        }
        Spacer(Modifier.height(28.dp))
        Text(
            "Welcome",
            color = Ink,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.sp,
            fontSize = 15.sp,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Create a private box or join with an invite.",
            color = Muted,
            fontSize = 13.sp,
        )
        Spacer(Modifier.height(48.dp))
        // Hidden entry: three taps on the seal expose the two lawful paths.
        if (true) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Button(
                    onClick = onClaim,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Coral, contentColor = Paper),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Outlined.Inbox, null, Modifier.size(18.dp))
                    Spacer(Modifier.size(8.dp))
                    Text("Claim this box as Owner", fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = onRedeem, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Key, null, Modifier.size(16.dp), tint = Muted)
                    Spacer(Modifier.size(8.dp))
                    Text("I have an invite token", color = Muted)
                }
            }
        } else {
            Text(
                "\u2014",
                color = Muted.copy(alpha = 0.35f),
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun ClaimPanel(vm: ChatViewModel, onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Zinc,
        border = BorderStroke(1.dp, CreamBorder),
        modifier = Modifier.padding(24.dp),
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Outlined.Shield, null, tint = Coral, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(16.dp))
            Text(
                "Calculator",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "An ECDH P-256 identity will be generated on this\ndevice. Your private key never leaves it.",
                color = Muted,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(24) },
                label = { Text("Owner codename") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (name.isNotBlank()) vm.claimBox(name) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold,
                    unfocusedBorderColor = CreamBorder,
                    focusedLabelColor = Gold,
                    unfocusedLabelColor = SoftGray,
                    cursorColor = Gold,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { vm.claimBox(name) },
                enabled = name.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Coral,
                    contentColor = Paper,
                    disabledContainerColor = CreamBorder,
                    disabledContentColor = SoftGray,
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Generate keys & seal the box", fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onBack) { Text("Back", color = Muted) }
        }
    }
}

@Composable
private fun RedeemPanel(vm: ChatViewModel, onBack: () -> Unit) {
    var token by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    val state by vm.state.collectAsState()
    val joining = state.joining
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Zinc,
        border = BorderStroke(1.dp, CreamBorder),
        modifier = Modifier.padding(24.dp),
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Outlined.Key, null, tint = Coral, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(14.dp))
            Text(
                "Redeem invite",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Invites allow exactly 2 joins, then self-destruct.\nThe box never holds more than 3 members.",
                color = Muted,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = token,
                onValueChange = { token = it },
                label = { Text("Invite link or token") },
                placeholder = { Text("/join?token=BX1.…", color = Muted.copy(alpha = 0.6f)) },
                singleLine = true,
                enabled = !joining,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold,
                    unfocusedBorderColor = CreamBorder,
                    focusedLabelColor = Gold,
                    unfocusedLabelColor = SoftGray,
                    cursorColor = Gold,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(24) },
                label = { Text("Your codename") },
                singleLine = true,
                enabled = !joining,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { vm.redeemInvite(token, name) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold,
                    unfocusedBorderColor = CreamBorder,
                    focusedLabelColor = Gold,
                    unfocusedLabelColor = SoftGray,
                    cursorColor = Gold,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { vm.redeemInvite(token, name) },
                enabled = token.isNotBlank() && name.isNotBlank() && !joining,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Coral,
                    contentColor = Paper,
                    disabledContainerColor = CreamBorder,
                    disabledContentColor = SoftGray,
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (joining) {
                    CircularProgressIndicator(
                        color = Gold,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Validating with the box…", fontWeight = FontWeight.SemiBold)
                } else {
                    Text("Join the box", fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onBack) { Text("Back", color = Muted) }
            Spacer(Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    "Note: the Owner must first claim this box and\ngenerate an invite from the management drawer.",
                    color = Muted.copy(alpha = 0.7f),
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}
