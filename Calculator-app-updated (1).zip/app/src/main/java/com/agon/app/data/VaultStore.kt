package com.agon.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.serialization.json.Json

private val Context.vaultDataStore by preferencesDataStore(name = "blackbox_vault")

/**
 * Encrypted-at-rest local vault. Serializes the zero-knowledge schema
 * (ciphertexts + IVs + key material) to DataStore. Offline-first: the
 * conversation survives process death and reloads without network.
 */
class VaultStore(private val context: Context) {

    private val key = stringPreferencesKey("vault_json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    suspend fun load(): StoredVault {
        val raw = context.vaultDataStore.data.first()[key] ?: return StoredVault()
        return runCatching { json.decodeFromString<StoredVault>(raw) }.getOrDefault(StoredVault())
    }

    suspend fun save(vault: StoredVault) {
        val raw = json.encodeToString(StoredVault.serializer(), vault)
        context.vaultDataStore.edit { it[key] = raw }
    }
}
