package com.agon.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.AddLink
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.ui.components.CoralBadge
import com.agon.app.ui.components.MemberAvatar
import com.agon.app.ui.components.PresenceDot
import com.agon.app.ui.theme.DangerRed
import com.agon.app.ui.theme.Coral
import com.agon.app.ui.theme.Cream
import com.agon.app.ui.theme.Coral
import com.agon.app.ui.theme.Paper
import com.agon.app.ui.theme.Muted
import com.agon.app.ui.theme.CreamBorder
import com.agon.app.ui.theme.Ink
import com.agon.app.ui.theme.CreamLine
import com.agon.app.ui.theme.Cream
import com.agon.app.ui.theme.OnlineGreen
import com.agon.app.ui.theme.Muted
import com.agon.app.ui.theme.Zinc
import com.agon.app.ui.theme.CreamBorder
import com.agon.app.viewmodel.ChatUiState
import com.agon.app.viewmodel.ChatViewModel
import com.agon.app.viewmodel.MAX_MEMBERS
import com.agon.app.viewmodel.MemberUi


/** Owner's management drawer: members, invites, key fingerprints, nuke. */
@Composable
fun ManageScreen(vm: ChatViewModel, state: ChatUiState, onBack: () -> Unit) {
    val context = LocalContext.current
    var removeTarget by remember { mutableStateOf<MemberUi?>(null) }
    var confirmDestroy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Cream)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(Zinc)
                .padding(horizontal = 6.dp, vertical = 8.dp),
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = MaterialTheme.colorScheme.onSurface)
            }
            Column {
                Text("Box Management", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    if (state.isOwner) "Owner controls" else "Member view",
                    color = Muted,
                    fontSize = 11.sp,
                )
            }
        }
        HorizontalDivider(color = CreamBorder)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // ------------------------------------------------ members card
            SectionCard(title = "MEMBERS \u00B7 ${state.members.size}/$MAX_MEMBERS") {
                state.members.forEachIndexed { index, member ->
                    if (index > 0) HorizontalDivider(color = CreamBorder.copy(alpha = 0.6f))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                    ) {
                        Box {
                            MemberAvatar(
                                name = member.name,
                                isOwner = member.isOwner,
                                glow = if (member.online) OnlineGreen else null,
                            )
                            PresenceDot(
                                online = member.online,
                                modifier = Modifier.align(Alignment.BottomEnd),
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Owner always shows as KING 👑 UMAR in settings
                                val displayName = if (member.isOwner) "King 👑 UMAR" else member.name
                                Text(displayName, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Ink)
                                Spacer(Modifier.width(8.dp))
                                if (member.isOwner) CoralBadge("OWNER") else CoralBadge("BUDDY")
                                if (member.isSelf) {
                                    Spacer(Modifier.width(6.dp))
                                    CoralBadge("YOU")
                                }
                            }
                            Spacer(Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Outlined.Fingerprint, null,
                                    tint = Muted, modifier = Modifier.size(12.dp),
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    member.fingerprint,
                                    color = Muted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                )
                            }
                            Spacer(Modifier.height(2.dp))
                            Text(
                                when {
                                    member.isSelf -> "online \u00B7 this device"
                                    member.online -> "online"
                                    else -> "offline \u00B7 " + formatLastSeen(member.lastSeenAt)
                                },
                                color = if (member.online) OnlineGreen else Muted.copy(alpha = 0.8f),
                                fontSize = 10.sp,
                            )
                            // Owner-only intel: how many times this buddy
                            // has opened the app.
                            if (state.isOwner && !member.isSelf && !member.isOwner) {
                                Spacer(Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Outlined.Visibility, null,
                                        tint = Coral.copy(alpha = 0.8f),
                                        modifier = Modifier.size(11.dp),
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        "opened ${member.openCount} time" +
                                            (if (member.openCount == 1) "" else "s") +
                                            " in last 24h",
                                        color = Coral.copy(alpha = 0.85f),
                                        fontSize = 10.sp,
                                    )
                                }
                            }
                        }
                        if (state.isOwner && !member.isOwner) {
                            IconButton(onClick = { removeTarget = member }) {
                                Icon(
                                    Icons.Default.PersonRemove,
                                    "Remove buddy",
                                    tint = DangerRed.copy(alpha = 0.85f),
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        }
                    }
                }
                if (state.members.size < MAX_MEMBERS) {
                    Text(
                        "${MAX_MEMBERS - state.members.size} seat(s) remaining. The ceiling is absolute.",
                        color = Muted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                } else {
                    Text(
                        "Box is at full capacity. No further joins are possible.",
                        color = Coral,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }

            // ------------------------------------------------- invite card
            if (!state.isOwner) {
                SectionCard(title = "ADD BUDDY \u00B7 INVITE LINK") {
                    Text(
                        "Only the Owner can mint or destroy invite links.",
                        color = Muted,
                        fontSize = 12.sp,
                    )
                }
            } else {
            SectionCard(title = "ADD BUDDY \u00B7 INVITE LINK") {
                if (state.inviteToken != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Cream,
                        border = BorderStroke(1.dp, Coral.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        ) {
                            Text(
                                "/join?token=${state.inviteToken.take(18)}\u2026${state.inviteToken.takeLast(8)}",
                                color = Coral,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 2,
                                modifier = Modifier.weight(1f),
                            )
                            IconButton(
                                onClick = {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(
                                        ClipData.newPlainText("invite", "/join?token=${state.inviteToken}")
                                    )
                                    vm.notice("Invite link copied. It self-destructs after ${state.inviteUsesLeft} join(s).")
                                },
                                modifier = Modifier.size(30.dp),
                            ) {
                                Icon(Icons.Default.ContentCopy, "Copy", tint = Muted, modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                onClick = {
                                    val send = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "/join?token=${state.inviteToken}")
                                    }
                                    context.startActivity(Intent.createChooser(send, "Share invite"))
                                },
                                modifier = Modifier.size(30.dp),
                            ) {
                                Icon(Icons.Default.Share, "Share", tint = Muted, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${state.inviteUsesLeft} join(s) remaining before self-destruct. The token is self-contained \u2014 send it to your buddy over any channel and it works on their device with no prior link to yours.",
                        color = Muted,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { vm.revokeInvite() },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Outlined.LinkOff, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Destroy invite link")
                    }
                } else {
                    Text(
                        if (state.members.size >= MAX_MEMBERS)
                            "The box is full. Invitations are permanently sealed."
                        else
                            "Mint a one-time link valid for exactly 2 joins. It expires automatically once used up or when the box reaches 3 members.",
                        color = Muted,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { vm.generateInvite() },
                        enabled = state.members.size < MAX_MEMBERS,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Coral,
                            contentColor = Cream,
                            disabledContainerColor = CreamBorder,
                            disabledContentColor = Muted,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Outlined.AddLink, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Generate invite link", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            }

            // ----------------------------------------------- security card
            SectionCard(title = "SECURITY") {
                SecurityRow("Key exchange", "ECDH \u00B7 P-256 (secp256r1)")
                SecurityRow("Payload cipher", "AES-GCM-256 \u00B7 96-bit IV")
                SecurityRow("Key storage", "On-device only \u00B7 never uploaded")
                SecurityRow("At rest", "Ciphertext + IV pairs only")
                SecurityRow("Channel", "Text-only \u00B7 links & media blocked")
                SecurityRow("Disappearing", "Messages self-destruct \u00B7 3h")
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Shield, null, tint = Coral, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Zero-knowledge: plaintext never touches storage.",
                        color = Coral,
                        fontSize = 11.sp,
                    )
                }
            }

            // --------------------------------------------- danger zone card
            SectionCard(title = "DANGER ZONE", borderColor = DangerRed.copy(alpha = 0.35f)) {
                Text(
                    if (state.isOwner)
                        "Destroys the box for every member: all keys, profiles and ciphertexts are wiped. This cannot be undone."
                    else
                        "Leaves the box and wipes all keys and ciphertexts from this device. This cannot be undone.",
                    color = Muted,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { confirmDestroy = true },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.6f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Outlined.DeleteForever, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (state.isOwner) "Destroy this box" else "Leave & wipe this device",
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            // Subtle premium owner credit — bottom of settings after full scroll
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    "Owner",
                    color = Muted.copy(alpha = 0.75f),
                    fontSize = 11.sp,
                    letterSpacing = 1.sp,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    "King 👑 UMAR",
                    color = Coral.copy(alpha = 0.9f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    // Remove buddy confirmation.
    removeTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { removeTarget = null },
            containerColor = Zinc,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = Muted,
            title = { Text("Remove ${target.name}?") },
            text = {
                Text("Their access profile will be deleted and their session revoked immediately. They cannot rejoin without a fresh invite.")
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.removeBuddy(target.id)
                    removeTarget = null
                }) { Text("Remove & revoke", color = DangerRed, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { removeTarget = null }) { Text("Cancel", color = Muted) }
            },
        )
    }

    if (confirmDestroy) {
        AlertDialog(
            onDismissRequest = { confirmDestroy = false },
            containerColor = Zinc,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = Muted,
            title = { Text(if (state.isOwner) "Destroy the box?" else "Leave the box?") },
            text = {
                Text(
                    if (state.isOwner)
                        "All keys, members and encrypted history will be wiped permanently \u2014 on every device."
                    else
                        "All keys and encrypted history will be wiped from this device permanently."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDestroy = false
                    vm.destroyBox()
                    onBack()
                }) {
                    Text(
                        if (state.isOwner) "Destroy everything" else "Leave & wipe",
                        color = DangerRed,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDestroy = false }) { Text("Cancel", color = Muted) }
            },
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    borderColor: androidx.compose.ui.graphics.Color = CreamBorder,
    content: @Composable () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Zinc,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                title,
                color = Muted,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.5.sp,
            )
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SecurityRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
}
