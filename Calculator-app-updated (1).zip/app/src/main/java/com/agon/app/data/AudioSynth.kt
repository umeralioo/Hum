package com.agon.app.data

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Tiny synthesizer for audio feedback. No sound assets: tones are
 * generated as PCM sine waves with an exponential decay envelope and
 * pushed through AudioTrack.
 */
object AudioSynth {

    private const val SAMPLE_RATE = 44100

    /** Clear low-frequency "pop/thud" on message send (audible, short). */
    fun playSend() {
        val samples = renderTone(
            partials = listOf(Partial(220f, 1.0f), Partial(110f, 0.7f), Partial(440f, 0.25f)),
            durationMs = 140,
            decay = 22.0,
            volume = 0.72f,
        )
        play(samples)
    }

    /** Gentle dual-tone chime on message receive. */
    fun playReceive() {
        val a = renderTone(
            partials = listOf(Partial(659.25f, 1.0f)),
            durationMs = 130,
            decay = 16.0,
            volume = 0.28f,
        )
        val b = renderTone(
            partials = listOf(Partial(880f, 1.0f), Partial(1318.5f, 0.3f)),
            durationMs = 220,
            decay = 12.0,
            volume = 0.28f,
        )
        play(a + b)
    }

    private data class Partial(val freq: Float, val amp: Float)

    private fun renderTone(
        partials: List<Partial>,
        durationMs: Int,
        decay: Double,
        volume: Float,
    ): ShortArray {
        val count = SAMPLE_RATE * durationMs / 1000
        val out = ShortArray(count)
        val ampSum = partials.sumOf { it.amp.toDouble() }.coerceAtLeast(1.0)
        for (i in 0 until count) {
            val t = i.toDouble() / SAMPLE_RATE
            val envelope = exp(-decay * t)
            var sample = 0.0
            for (p in partials) {
                sample += p.amp * sin(2.0 * PI * p.freq * t)
            }
            sample = sample / ampSum * envelope * volume
            out[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    private fun play(samples: ShortArray) {
        thread(isDaemon = true) {
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .setBufferSizeInBytes(samples.size * 2)
                    .build()
                track.write(samples, 0, samples.size)
                track.play()
                Thread.sleep(samples.size * 1000L / SAMPLE_RATE + 80)
                track.release()
            } catch (_: Exception) {
                // Audio is best-effort polish; never crash the channel.
            }
        }
    }
}
