package com.agon.app.data

import android.util.Base64
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Client-side cryptographic engine.
 *
 * Protocol:
 *  - ECDH identity key pairs on the P-256 (secp256r1) curve per member,
 *    used for member fingerprints (safety numbers).
 *  - A 256-bit channel secret minted by the owner and shared ONLY inside
 *    the out-of-band invite token -> SHA-256 KDF -> AES-256 channel key.
 *  - Every payload sealed with AES-GCM-256 (96-bit random IV, 128-bit tag).
 *
 * The relay and the vault (at rest) only ever see Base64 ciphertext + IV.
 */
object CryptoEngine {

    private val random = SecureRandom()

    fun generateKeyPair(): KeyPair {
        val kpg = KeyPairGenerator.getInstance("EC")
        kpg.initialize(ECGenParameterSpec("secp256r1"), random)
        return kpg.generateKeyPair()
    }

    /** ECDH agreement + SHA-256 KDF -> AES-256 key. */
    fun deriveSharedKey(privateKey: PrivateKey, publicKey: PublicKey): SecretKey {
        val agreement = KeyAgreement.getInstance("ECDH")
        agreement.init(privateKey)
        agreement.doPhase(publicKey, true)
        val sharedSecret = agreement.generateSecret()
        val keyBytes = MessageDigest.getInstance("SHA-256").digest(sharedSecret)
        return SecretKeySpec(keyBytes, "AES")
    }

    /** Fresh 256-bit channel secret (goes only into the invite token). */
    fun newChannelSecret(): String {
        val bytes = ByteArray(32).also { random.nextBytes(it) }
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /** SHA-256 KDF over the channel secret -> AES-256 channel key. */
    fun channelKeyFromSecret(secretB64: String): SecretKey {
        val secret = Base64.decode(secretB64, Base64.NO_WRAP)
        val keyBytes = MessageDigest.getInstance("SHA-256").digest(secret)
        return SecretKeySpec(keyBytes, "AES")
    }

    /** Returns (ivBase64, ciphertextBase64). */
    fun encrypt(key: SecretKey, plaintext: String): Pair<String, String> {
        val iv = ByteArray(12).also { random.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv, Base64.NO_WRAP) to Base64.encodeToString(ct, Base64.NO_WRAP)
    }

    fun decrypt(key: SecretKey, ivB64: String, ciphertextB64: String): String {
        val iv = Base64.decode(ivB64, Base64.NO_WRAP)
        val ct = Base64.decode(ciphertextB64, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ct), Charsets.UTF_8)
    }

    fun encodePublic(key: PublicKey): String =
        Base64.encodeToString(key.encoded, Base64.NO_WRAP)

    fun encodePrivate(key: PrivateKey): String =
        Base64.encodeToString(key.encoded, Base64.NO_WRAP)

    fun decodePublic(b64: String): PublicKey =
        KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(b64, Base64.NO_WRAP)))

    fun decodePrivate(b64: String): PrivateKey =
        KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(Base64.decode(b64, Base64.NO_WRAP)))

    /** Human-verifiable safety-number style fingerprint of a public key. */
    fun fingerprint(key: PublicKey): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(key.encoded)
        return digest.take(8).joinToString(" ") { String.format("%02X", it) }
    }

    fun fingerprintB64(pubB64: String): String =
        runCatching { fingerprint(decodePublic(pubB64)) }.getOrDefault("\u2014 unverified \u2014")

    /** Random hex id, e.g. for box ids and invite ids. */
    fun randomId(bytes: Int = 12): String {
        val buf = ByteArray(bytes).also { random.nextBytes(it) }
        return buf.joinToString("") { String.format("%02x", it) }
    }

    /** One-time invite token id, e.g. bx-9f3a1c... */
    fun newInviteToken(): String = "bx-" + randomId(6)
}
